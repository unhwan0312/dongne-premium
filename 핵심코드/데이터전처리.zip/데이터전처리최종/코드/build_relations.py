"""
단지 ↔ 시설 관계형 테이블 (도보) — 리메이크판 (단독 실행)
==========================================================
apt_accessibility15.py 없이 이 파일 하나만 실행하면 됩니다. (python build_relations.py)
필요한 함수(시설 불러오기·도로망 캐시·'길 위 지점' 연결 등)를 이 파일 안에 옮겨 넣었고,
관계 테이블에 쓰이지 않는 부분(차량 도로망·최근접 넓은 표·유흥 밀도·항공기 소음·OSM 주소 검색)은 뺐습니다.

폴더 구성: 코드/ (이 파일) · 입력데이터/ (입력 CSV + 도로망/) · 결과/ (출력)
  - 단지 목록·좌표: 입력데이터/daegu_apt_trades_좌표.csv (거래마다 위도·경도가 붙은 23~26년 실거래)
      해제 거래·군위군·LAST_YM 이후 거래 제외 → 단지 좌표 = 그 단지 거래 좌표의 최빈값
      좌표가 없는 단지는 빼고 명단 출력
  - 도로망: 도보만 씀 (입력데이터/도로망/daegu_walk.graphml, 없으면 OSM에서 받아 저장)
  - 하수처리장 좌표: 입력 파일 값만 씀 (OSM 검색 안 함)
  - OSM 요청 캐시·파이썬 캐시(__pycache__)를 만들지 않음

출력 (결과/)
  rel_단지_시설.csv   [관계 테이블] 한 행 = (단지, 시설) 한 쌍
      complex_id, 시설유형, 시설ID, 시설명, 기준, 도보_분, 직선거리_m, 구간, 순위
      - 도보 범위(기본 REL_CUTOFF_MIN분, 유형별로 REL_CUTOFF_BY_TYPE) 안에 닿는 시설만 전부 (범위 방식)
        → 범위 안에 시설이 없는 단지는 그 유형 행이 없음 (집계할 때 dim_단지 기준으로 0을 채움)
      - NEAREST_GUARANTEE = True 로 바꾸면 최근접형 시설은 범위 밖이어도 가장 가까운 1곳을 넣음
      - 순위: 범위 안에서 같은 유형 시설의 가까운 순서 (1 = 범위 안 최근접)
      - 도시철도역은 역 단위로 묶음: 시설ID = 역, 시설명 = 그 역에서 가장 가까운 출구
      - 기준: 도보 / 직선. STRAIGHT_RANGE_M 유형(기본 하수처리장 3km)은 냄새·소음처럼 길과 무관하게 퍼지므로
        직선거리 범위로 엮고 구간도 500m이내 / 1000m이내 … (도보_분은 빈칸)
  fac_권역_요약.csv   [시설 기준] 시설마다 구간별 단지 수 · 권역 단지 수
  dim_시설.csv        [시설 목록] 시설유형, 시설ID, 시설명, 위도, 경도, 도로연결(m) + 유형별 속성(노선수 등)
  dim_단지.csv        [단지 목록] complex_id, 단지명, 구, 위도, 경도, 도로연결(m)

설치 (PC에서 1회):  pip install osmnx scikit-learn scipy
데이터 출처 표기: 도로망은 © OpenStreetMap contributors (ODbL). 발표·보고서에 반드시 표기하세요.
"""
import os
import sys
import re
import glob
import time
import heapq
import itertools
import unicodedata
import warnings

sys.dont_write_bytecode = True       # 코드/ 폴더에 __pycache__ 를 만들지 않음

import numpy as np
import pandas as pd
import networkx as nx

warnings.filterwarnings("ignore")

# ==================================================================
# 0. 설정
# ==================================================================
CODE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(CODE_DIR)                  # 배채정(리메이크) 폴더
DATA_DIR = os.path.join(BASE_DIR, "입력데이터")
OUT_DIR = os.path.join(BASE_DIR, "결과")
GRAPH_DIR = os.path.join(DATA_DIR, "도로망")           # 도로망 캐시 (daegu_walk.graphml)

# --- 시간 구간 ---
TIME_BINS = [5, 10, 15, 20]                                        # 구간 경계(분), 오른쪽 끝 포함
TIME_LABELS = ["5분이내", "10분이내", "15분이내", "20분이내", "20분초과"]
NO_INFO_LABEL = "정보없음"
assert len(TIME_LABELS) == len(TIME_BINS) + 1, "TIME_LABELS는 TIME_BINS보다 1개 많아야 합니다"

# --- 시설 ---
NEAREST_FACILITIES = ["도시철도역", "초등학교", "중학교", "고등학교", "공원", "종합병원", "대형마트", "하수처리장"]
COUNT_FACILITIES = ["입시학원", "편의점", "의원", "음식점"]
ALL_TYPES = NEAREST_FACILITIES + COUNT_FACILITIES + ["버스정류장", "유흥주점"]
PARK_TYPES = ["근린공원", "수변공원", "체육공원", "문화공원", "역사공원"]
SEWAGE_MIN_TON = 20000                       # 하수처리장: 시설용량(톤/일) 이 이상만
ENT_CRS = "EPSG:5174"                        # 유흥주점 인허가 '좌표정보(X/Y)' 좌표계
SUBWAY_BY_EXIT = True                        # 도시철도역은 출입구 좌표 기준 (출입구 정보 없는 역은 역 중심)
BUS_STOP_FILE = "버스정류장좌표.csv"          # 내용으로 못 찾을 때 이름으로 한 번 더 찾음
EXCLUDE_GU = ["군위군"]                      # 분석에서 뺄 지역

# --- 도보 계산 ---
WALK_SPEED_MPS = 1.2           # 보행 속도 (약 4.3km/h). 고령자 기준이면 1.0
SNAP_PIECE_M = 25              # 길 연결 검색용 조각 길이(m)
SNAP_CANDIDATES = 12           # 점마다 살펴볼 길 조각 후보 수
SNAP_LAT0 = 35.87              # 평면 근사 기준 위도 (대구)
EARTH_R_M = 6371008.8
BBOX_PAD_DEG = 0.02            # 단지 범위 바깥으로 여유 (약 2km)

# --- OSM 다운로드 (도로망 캐시가 없을 때만) ---
OVERPASS_URLS = ["https://overpass-api.de/api",
                 "https://overpass.kumi.systems/api",
                 "https://overpass.private.coffee/api"]
OVERPASS_MAX_TRY = 8
OVERPASS_WAIT_SEC = 30
QUERY_TILE_M2 = 100_000_000    # 한 번에 요청할 면적 (약 10km × 10km)
REBUILD_GRAPH = False          # True = 캐시가 있어도 무시하고 OSM에서 다시 받기

# --- 관계 테이블 ---
REL_CUTOFF_MIN = 20                 # 기본 범위(분): 이 시간 안에 닿는 시설만 관계 테이블에 넣음
REL_CUTOFF_BY_TYPE = {}             # 유형별 범위(분). 예: {"음식점": 10, "편의점": 10, "종합병원": 30}
NEAREST_GUARANTEE = False           # True : 최근접형(아래 유형)은 범위 밖이어도 가장 가까운 1곳을 넣음
NEAREST_TYPES = NEAREST_FACILITIES
STRAIGHT_RANGE_M = {"하수처리장": 3000}    # 직선거리 범위로 엮을 유형 {유형: 범위 m}
STRAIGHT_BINS_M = [500, 1000, 2000, 3000]  # 직선거리 구간 경계
REL_DIR = OUT_DIR
APT_FILE = "daegu_apt_trades_좌표.csv"   # 입력데이터/ 안의 좌표 붙은 실거래 (23~26년)
LAST_YM = 202609                    # 이 달(YYYYMM)까지의 거래로 단지 목록을 만듦


# ==================================================================
# 유틸
# ==================================================================
def _norm(s):
    return unicodedata.normalize("NFC", s).lower().replace(" ", "")


def find_file(filename, required=True):
    target = _norm(filename)
    for p in glob.glob(os.path.join(DATA_DIR, "**", "*.*"), recursive=True):
        if _norm(os.path.basename(p)) == target:
            return p
    if required:
        raise FileNotFoundError(f"'{filename}'을 찾을 수 없습니다 (DATA_DIR={DATA_DIR})")
    return None


def read_any(path, **kw):
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            return pd.read_csv(path, encoding=enc, low_memory=False, **kw)
        except UnicodeDecodeError:
            continue
    raise ValueError(path)


def find_tables(need, exts=("csv",)):
    """DATA_DIR 안에서 컬럼 need를 모두 가진 표 전부 [(경로, 표), ...] (파일 이름과 무관하게 내용으로)"""
    out = []
    for path in sorted(glob.glob(os.path.join(DATA_DIR, "**", "*.*"), recursive=True)):
        if path.lower().rsplit(".", 1)[-1] not in exts:
            continue
        try:
            if need <= set(read_any(path, nrows=3).columns):
                out.append((path, read_any(path)))
        except Exception:
            continue
    return out


def find_table(need, exts=("csv",)):
    found = find_tables(need, exts)
    return found[0] if found else (None, None)


def haversine_m(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * EARTH_R_M * np.arcsin(np.sqrt(a))


def facility_table(df_, name_col, lat="위도", lon="경도", extra=None):
    """시설 표 → [이름, 위도, 경도 (+extra)] (좌표 없는 행 제외). 이름 컬럼이 없으면 '이름 없음'"""
    d = pd.DataFrame({"이름": df_[name_col] if name_col in df_ else "이름 없음",
                      "위도": pd.to_numeric(df_[lat], errors="coerce"),
                      "경도": pd.to_numeric(df_[lon], errors="coerce")})
    for k, v in (extra or {}).items():
        d[k] = v
    d["이름"] = d["이름"].fillna("이름 없음").astype(str).str.strip()
    return d.dropna(subset=["위도", "경도"]).reset_index(drop=True)


def time_bin(minutes):
    """분 → 구간 이름 (표시값 기준: 소수 첫째 자리 반올림 후 판정, 경계값 포함)"""
    m = pd.Series(minutes, dtype=float).round(1)
    lab = pd.cut(m, [-np.inf] + list(TIME_BINS) + [np.inf], labels=TIME_LABELS, right=True)
    return lab.astype(object).where(m.notna(), NO_INFO_LABEL)


def road_key(addr):
    """주소 → '동성로5길80' 같은 도로명+건물번호 키 (주소 대조용)"""
    m = re.search(r"([가-힣0-9]+(?:로|길))\s*(\d+(?:-\d+)?)", str(addr))
    return m.group(1) + m.group(2) if m else None


# ==================================================================
# 평면 TM 좌표(EPSG:5174) → WGS84 위경도 (pyproj 없이, 유흥주점 인허가·하수처리장 좌표용)
# ==================================================================
BESSEL = (6377397.155, 1 / 299.1528128)
WGS84 = (6378137.0, 1 / 298.257223563)
CRS = {"EPSG:5174": dict(lat0=38.0, lon0=127.0028902777778, k0=1.0, fe=200000, fn=500000,
                         towgs84=(-115.80, 474.99, 674.11, 1.16, -2.31, -1.63, 6.43))}


def _meridian(phi, a, e2):
    e4, e6 = e2 * e2, e2 ** 3
    return a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
                - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * np.sin(2 * phi)
                + (15 * e4 / 256 + 45 * e6 / 1024) * np.sin(4 * phi)
                - (35 * e6 / 3072) * np.sin(6 * phi))


def _tm_inverse(x, y, a, f, lat0, lon0, k0, fe, fn):
    """횡메르카토르 역변환 (Snyder 식) → 같은 타원체의 위경도(도)"""
    e2 = f * (2 - f)
    ep2 = e2 / (1 - e2)
    M = _meridian(np.radians(lat0), a, e2) + (y - fn) / k0
    mu = M / (a * (1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256))
    e1 = (1 - np.sqrt(1 - e2)) / (1 + np.sqrt(1 - e2))
    phi1 = (mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * np.sin(2 * mu) + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * np.sin(4 * mu)
            + (151 * e1 ** 3 / 96) * np.sin(6 * mu) + (1097 * e1 ** 4 / 512) * np.sin(8 * mu))
    C1, T1 = ep2 * np.cos(phi1) ** 2, np.tan(phi1) ** 2
    N1 = a / np.sqrt(1 - e2 * np.sin(phi1) ** 2)
    R1 = a * (1 - e2) / (1 - e2 * np.sin(phi1) ** 2) ** 1.5
    D = (x - fe) / (N1 * k0)
    lat = phi1 - (N1 * np.tan(phi1) / R1) * (D ** 2 / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 ** 2 - 9 * ep2) * D ** 4 / 24
                                             + (61 + 90 * T1 + 298 * C1 + 45 * T1 ** 2 - 252 * ep2 - 3 * C1 ** 2) * D ** 6 / 720)
    lon = np.radians(lon0) + (D - (1 + 2 * T1 + C1) * D ** 3 / 6
                              + (5 - 2 * C1 + 28 * T1 - 3 * C1 ** 2 + 8 * ep2 + 24 * T1 ** 2) * D ** 5 / 120) / np.cos(phi1)
    return np.degrees(lat), np.degrees(lon)


def _to_ecef(lat, lon, a, f, h=0.0):
    e2 = f * (2 - f)
    la, lo = np.radians(lat), np.radians(lon)
    N = a / np.sqrt(1 - e2 * np.sin(la) ** 2)
    return (N + h) * np.cos(la) * np.cos(lo), (N + h) * np.cos(la) * np.sin(lo), (N * (1 - e2) + h) * np.sin(la)


def _from_ecef(X, Y, Z, a, f):
    e2 = f * (2 - f)
    lon = np.arctan2(Y, X)
    p = np.hypot(X, Y)
    lat = np.arctan2(Z, p * (1 - e2))
    for _ in range(6):
        N = a / np.sqrt(1 - e2 * np.sin(lat) ** 2)
        h = p / np.cos(lat) - N
        lat = np.arctan2(Z, p * (1 - e2 * N / (N + h)))
    return np.degrees(lat), np.degrees(lon)


def tm_to_wgs84(x, y, crs=ENT_CRS):
    """평면 좌표 배열 → (위도, 경도) WGS84. towgs84는 proj와 같은 position-vector 규약"""
    p = CRS[crs]
    a, f = BESSEL
    lat, lon = _tm_inverse(np.asarray(x, float), np.asarray(y, float), a, f, p["lat0"], p["lon0"], p["k0"], p["fe"], p["fn"])
    tx, ty, tz, rx, ry, rz, s = p["towgs84"]
    rx, ry, rz = (np.radians(v / 3600) for v in (rx, ry, rz))
    s = 1 + s * 1e-6
    X, Y, Z = _to_ecef(lat, lon, a, f)
    X2 = tx + s * (X - rz * Y + ry * Z)
    Y2 = ty + s * (rz * X + Y - rx * Z)
    Z2 = tz + s * (-ry * X + rx * Y + Z)
    return _from_ecef(X2, Y2, Z2, *WGS84)


# ==================================================================
# 시설 불러오기
# ==================================================================
def find_bus_csv():
    """DATA_DIR 안에서 '정류소명·위도·경도' 컬럼이 있는 CSV (내용으로)"""
    for path in sorted(glob.glob(os.path.join(DATA_DIR, "**", "*.csv"), recursive=True)):
        try:
            head = read_any(path, nrows=5)
        except Exception:
            continue
        if {"정류소명", "위도", "경도"} <= set(head.columns):
            return path
    return find_file(BUS_STOP_FILE, required=False)


def find_exit_table():
    """DATA_DIR 안에서 '역명·출구번호·위도·경도' 컬럼이 있는 표 (xlsx 모든 시트·csv)"""
    need = {"역명", "출구번호", "위도", "경도"}
    for path in sorted(glob.glob(os.path.join(DATA_DIR, "**", "*.*"), recursive=True)):
        ext = path.lower().rsplit(".", 1)[-1]
        try:
            if ext in ("xlsx", "xls"):
                for sheet, d in pd.read_excel(path, sheet_name=None).items():
                    if need <= set(d.columns):
                        return f"{os.path.basename(path)} [{sheet}]", d
            elif ext == "csv" and need <= set(read_any(path, nrows=5).columns):
                return os.path.basename(path), read_any(path)
        except Exception:
            continue
    return None, None


def subway_facilities(subway, exits):
    """
    도시철도역 시설 표. exits가 있으면 출입구마다 '같은 호선에서 가장 가까운 역' 이름으로 맞춤.
    이름 = '범어역 8번 출구'. 출입구 정보가 없는 역은 역 중심 좌표로 대체.
    """
    from sklearn.neighbors import BallTree
    centers = subway.drop_duplicates("원역명")
    if exits is None:
        return facility_table(centers, "이름"), None
    ex = exits.dropna(subset=["역명", "위도", "경도"]).copy()
    ex["line"] = pd.to_numeric(ex["호선"].astype(str).str.extract(r"(\d+)")[0], errors="coerce")
    st = subway.copy()
    st["line"] = pd.to_numeric(st["분류"].astype(str).str.extract(r"(\d+)")[0], errors="coerce")
    ex["역"], ex["역까지(m)"] = None, np.nan
    for line, g in ex.groupby("line"):
        s = st[st["line"] == line] if (st["line"] == line).any() else st
        d, i = BallTree(np.radians(s[["위도", "경도"]].values), metric="haversine").query(
            np.radians(g[["위도", "경도"]].values), k=1)
        ex.loc[g.index, "역"] = s["이름"].values[i[:, 0]]
        ex.loc[g.index, "역까지(m)"] = d[:, 0] * EARTH_R_M
    ex = ex.drop_duplicates(["역", "출구번호", "위도", "경도"])
    with_yeok = lambda s: s.where(s.str.endswith("역"), s + "역")
    ex["이름"] = with_yeok(ex["역"].astype(str)) + " " + ex["출구번호"].astype(str) + "번 출구"
    no_exit = centers[~centers["이름"].isin(ex["역"])].copy()
    no_exit["이름"] = with_yeok(no_exit["이름"].astype(str)) + "(출입구 정보 없음, 역 중심)"
    table = pd.concat([facility_table(ex, "이름"), facility_table(no_exit, "이름")], ignore_index=True)
    renamed = (ex.assign(원래=ex["역명"].astype(str).str.replace(r"\d+$", "", regex=True))
               .query("원래 != 역")[["역명", "역"]].drop_duplicates())
    info = dict(n_exit=len(ex), n_station=ex["역"].nunique(), no_exit=list(no_exit["이름"]),
                renamed=list(map(tuple, renamed.values)), far=float(ex["역까지(m)"].max()))
    return table, info


def load_entertainment(restaurants):
    """유흥주점 인허가 CSV(업태구분명·좌표정보(X/Y)) → [이름, 위도, 경도]. 좌표 빈 업소는 같은 주소 음식점 좌표로"""
    path, u = find_table({"업태구분명", "좌표정보(X)", "좌표정보(Y)"})
    if u is None:
        print("    유흥주점: 인허가 파일 없음")
        return facility_table(pd.DataFrame(columns=["이름", "위도", "경도"]), "이름")
    if "영업상태명" in u:
        u = u[u["영업상태명"].astype(str).str.contains("영업")]
    lat, lon = tm_to_wgs84(pd.to_numeric(u["좌표정보(X)"], errors="coerce"),
                           pd.to_numeric(u["좌표정보(Y)"], errors="coerce"))
    u = u.assign(위도=lat, 경도=lon)
    miss = u["위도"].isna()
    if miss.any():
        rk = restaurants.assign(k=restaurants["주소"].map(road_key)).dropna(subset=["k"]).groupby("k")[["위도", "경도"]].median()
        k = u.loc[miss, "도로명주소"].map(road_key)
        u.loc[miss, ["위도", "경도"]] = rk.reindex(k).values
    filled, still = int(miss.sum() - u["위도"].isna().sum()), int(u["위도"].isna().sum())
    print(f"    유흥주점: {os.path.basename(path)} {len(u):,}곳 ({ENT_CRS} 변환"
          + (f", 좌표 빈 {int(miss.sum())}곳 중 {filled}곳은 같은 주소 음식점 좌표로 채움" if miss.any() else "")
          + (f", {still}곳은 위치 불명으로 제외" if still else "") + ")")
    return facility_table(u, "사업장명")


def sewage_coords(s):
    """하수처리시설 표에서 좌표 컬럼을 찾아 (위도, 경도, 설명). 평면 좌표면 ENT_CRS로 변환"""
    cols = {str(c).strip().lower(): c for c in s.columns}
    num = lambda c: pd.to_numeric(s[c], errors="coerce").values
    for la, lo in [("위도", "경도"), ("lat", "lon"), ("lat", "lng"), ("latitude", "longitude"), ("y", "x"),
                   ("좌표정보(y)", "좌표정보(x)"), ("좌표(y)", "좌표(x)")]:
        if la in cols and lo in cols:
            y, x = num(cols[la]), num(cols[lo])
            if np.nanmax(np.abs(y)) < 90 and np.nanmax(np.abs(x)) < 180:
                return y, x, f"'{cols[la]}'·'{cols[lo]}' 위경도"
            lat_, lon_ = tm_to_wgs84(x, y)
            return lat_, lon_, f"'{cols[lo]}'·'{cols[la]}' 평면좌표({ENT_CRS} 변환)"
    return np.full(len(s), np.nan), np.full(len(s), np.nan), None


def load_sewage():
    """공공하수처리시설 현황(시설명·시설용량) → 시설용량 SEWAGE_MIN_TON 이상만 [이름, 시설명, 소재지, 시설용량, 위도, 경도]"""
    found = find_tables({"시설명", "시설용량"})
    with_xy = [(p, d) for p, d in found if sewage_coords(d)[2]]
    path, s = (with_xy or found or [(None, None)])[0]
    if s is None:
        print("    하수처리장: 시설 현황 파일 없음")
        return pd.DataFrame(columns=["이름", "위도", "경도", "소재지", "시설용량"])
    if len(found) > 1:
        print(f"    하수처리장: 후보 파일 {len(found)}개 중 {os.path.basename(path)} 사용"
              + (" (좌표 있는 파일 우선)" if with_xy else ""))
    s = s[pd.to_numeric(s["시설용량"], errors="coerce") >= SEWAGE_MIN_TON].copy()
    lat, lon, how = sewage_coords(s)
    out = pd.DataFrame({"이름": s["시설명"].astype(str).str.strip() + "하수처리장",
                        "시설명": s["시설명"].astype(str).str.strip(),
                        "소재지": s.get("소재지", pd.Series(index=s.index, dtype=object)),
                        "시설용량": pd.to_numeric(s["시설용량"]),
                        "위도": lat, "경도": lon})
    if how:
        print(f"    하수처리장 좌표: 파일의 {how} 사용 ({out['위도'].notna().sum()}/{len(out)}곳)")
    print(f"    하수처리장: {os.path.basename(path)} — 시설용량 {SEWAGE_MIN_TON:,}톤/일 이상 {len(out)}곳")
    return out.reset_index(drop=True)


def load_facilities():
    school = read_any(find_file("학교좌표.csv"))
    acad = read_any(find_file("학원좌표.csv"))
    subway = read_any(find_file("도시철도역좌표.csv"))
    hosp = read_any(find_file("병원좌표.csv"))
    park = read_any(find_file("공원좌표.csv"))
    rest = read_any(find_file("음식점좌표.CSV"))
    infra = {
        "초등학교": facility_table(school[school["분류"] == "초등학교"], "이름"),
        "중학교": facility_table(school[school["분류"] == "중학교"], "이름"),
        "고등학교": facility_table(school[school["분류"] == "고등학교"], "이름"),
        "입시학원": facility_table(acad[acad["분야구분"] == "입시.검정 및 보습"], "이름"),
        "대형마트": facility_table(read_any(find_file("대형마트좌표.csv")), "이름"),
        "편의점": facility_table(read_any(find_file("편의점슈퍼좌표.csv")), "이름"),
        "의원": facility_table(read_any(find_file("의원좌표.csv")), "이름"),
        "음식점": facility_table(rest, "이름"),
        "공원": facility_table(park[park["분류"].isin(PARK_TYPES)], "이름"),
    }
    if {"좌표(Y)", "좌표(X)"} <= set(hosp.columns):        # 심평원 원본 형식
        infra["종합병원"] = facility_table(hosp[hosp["종별코드명"].isin(["상급종합", "종합병원"])], "요양기관명",
                                       lat="좌표(Y)", lon="좌표(X)")
    else:                                                  # 요소별좌표 형식
        infra["종합병원"] = facility_table(hosp[hosp["분류"].isin(["상급종합", "종합병원"])], "이름")

    exit_src, exits = find_exit_table() if SUBWAY_BY_EXIT else (None, None)
    infra["도시철도역"], info = subway_facilities(subway, exits)
    if info:
        print(f"    도시철도역: 출입구 기준 ({exit_src}) — 출입구 {info['n_exit']}개 / 역 {info['n_station']}개, "
              f"출입구~역 최대 {info['far']:.0f}m")
        if info["renamed"]:
            print("      역 이름 맞춤: " + ", ".join(f"{a}→{b}" for a, b in info["renamed"]))
        if info["no_exit"]:
            print("      출입구 정보 없어 역 중심 사용: " + ", ".join(info["no_exit"]))
    else:
        print("    도시철도역: 역 중심 좌표 기준")

    bus_path = find_bus_csv()
    if bus_path:
        bus = read_any(bus_path)
        if "경유노선수" in bus:
            routes = pd.to_numeric(bus["경유노선수"], errors="coerce")
        elif "경유노선" in bus:
            routes = bus["경유노선"].fillna("").astype(str).map(lambda s: len({x.strip() for x in s.split("+") if x.strip()}))
        else:
            routes = None
        infra["버스정류장"] = facility_table(bus, "정류소명" if "정류소명" in bus else "이름",
                                         extra={"노선수": routes} if routes is not None else None)
        print(f"    버스정류장: {os.path.basename(bus_path)}" + ("" if routes is not None else " (경유 노선 정보 없음)"))

    infra["유흥주점"] = load_entertainment(rest)
    infra["하수처리장"] = load_sewage()
    for k in ALL_TYPES:
        if k in infra:
            print(f"    {k}: {len(infra[k]):,}개")
    return infra


# ==================================================================
# 도로망 (OSM)
# ==================================================================
def overpass_retry(ox, fn, what):
    wait = OVERPASS_WAIT_SEC
    for attempt in range(1, OVERPASS_MAX_TRY + 1):
        url = OVERPASS_URLS[(attempt - 1) % len(OVERPASS_URLS)]
        ox.settings.overpass_url = url
        try:
            return fn()
        except Exception as ex:
            msg = str(ex).splitlines()[0][:150]
            if attempt == OVERPASS_MAX_TRY:
                raise RuntimeError(
                    f"{what} 다운로드가 {OVERPASS_MAX_TRY}번 모두 실패했습니다. 인터넷 연결을 확인하거나, "
                    f"예전 폴더의 daegu_walk.graphml 을 {GRAPH_DIR} 로 복사하세요.\n마지막 오류: {msg}") from ex
            print(f"    {what}: 서버 응답 실패 ({url}) → {wait}초 후 다른 서버로 재시도 [{attempt}/{OVERPASS_MAX_TRY}]")
            time.sleep(wait)
            wait = min(wait * 2, 300)


def get_walk_graph(ox, bbox):
    """도보 도로망: 캐시(입력데이터/도로망/daegu_walk.graphml) 사용, 없으면 OSM에서 받아 저장"""
    path = os.path.join(GRAPH_DIR, "daegu_walk.graphml")
    if os.path.exists(path) and not REBUILD_GRAPH:
        print(f"    walk 도로망: 캐시 사용 ({path})")
        return ox.load_graphml(path)
    print("    walk 도로망 다운로드 중... (수 분~수십 분 걸릴 수 있음)")
    G = overpass_retry(ox, lambda: ox.graph_from_bbox(bbox=bbox, network_type="walk", simplify=True), "walk 도로망")
    ox.save_graphml(G, path)
    return G


def bbox_of(df_, pad=BBOX_PAD_DEG):
    return (df_["경도"].min() - pad, df_["위도"].min() - pad, df_["경도"].max() + pad, df_["위도"].max() + pad)


def load_osm_bus_stops(ox, bbox):
    cache = os.path.join(GRAPH_DIR, "bus_stops_osm.csv")
    if REBUILD_GRAPH or not os.path.exists(cache):
        gdf = overpass_retry(ox, lambda: ox.features_from_bbox(bbox=bbox, tags={"highway": "bus_stop"}), "버스정류장")
        pts = gdf.geometry.centroid
        names = gdf["name"].values if "name" in gdf else ["이름 없음"] * len(gdf)
        pd.DataFrame({"이름": names, "위도": pts.y.values, "경도": pts.x.values}).to_csv(
            cache, index=False, encoding="utf-8-sig")
    return facility_table(read_any(cache), "이름")


# ==================================================================
# 도로망 계산
# ==================================================================
def _edge_weight(edges, weight):
    """두 교차점 사이 간선(여러 개일 수 있음) 중 최소 가중치"""
    if weight in edges:                                  # 단일 그래프(Graph/DiGraph)
        return float(edges[weight])
    return min(float(e.get(weight, np.inf)) for e in edges.values())   # MultiGraph 계열


def nearest_labeled(G, src_nodes, src_cost, weight):
    """여러 시설에서 동시에 퍼져 나가는 다중 출발 Dijkstra → (거리 dict, 가장 가까운 시설 번호 dict)"""
    dist, lab, heap, tie = {}, {}, [], itertools.count()
    for i, (n, c) in enumerate(zip(src_nodes, src_cost)):
        if c < dist.get(n, np.inf):
            dist[n], lab[n] = float(c), i
    for n, c in dist.items():
        heap.append((c, next(tie), n))
    heapq.heapify(heap)
    adj, done = G._adj, set()
    while heap:
        d, _, u = heapq.heappop(heap)
        if u in done:
            continue
        done.add(u)
        for v, edges in adj[u].items():
            nd = d + _edge_weight(edges, weight)
            if nd < dist.get(v, np.inf):
                dist[v], lab[v] = nd, lab[u]
                heapq.heappush(heap, (nd, next(tie), v))
    return dist, lab


def _local_xy(lon, lat):
    """위경도 → 대구 기준 평면 좌표(m). 도시 범위에서 오차 0.5% 미만"""
    kx = np.radians(1) * EARTH_R_M * np.cos(np.radians(SNAP_LAT0))
    ky = np.radians(1) * EARTH_R_M
    return np.asarray(lon, float) * kx, np.asarray(lat, float) * ky, kx, ky


def attach_points(G, tables, verbose=True):
    """
    점(단지·시설)을 '가장 가까운 길(선분) 위의 지점'에 연결. 그 지점에 가상 교차점을 끼워 넣어 길을 쪼갬.
    tables: {이름: 위도·경도 표} — 모든 점을 한 번에 넣어야 같은 길을 겹치지 않게 쪼갤 수 있음
    반환: (새 도보 도로망(무방향), {이름: (가상 교차점 목록, 점→길 수직 거리 m 배열)})
    """
    from scipy.spatial import cKDTree
    say = print if verbose else (lambda *a, **k: None)

    # 1) 무방향 단순 그래프 — 두 교차점 사이 가장 짧은 간선만, 모양(geometry)도 함께
    H = nx.Graph()
    for n, d in G.nodes(data=True):
        H.add_node(n, x=float(d["x"]), y=float(d["y"]))
    for u, v, d in G.edges(data=True):
        L = float(d.get("length", np.inf))
        if u == v or not np.isfinite(L) or (H.has_edge(u, v) and H[u][v]["length"] <= L):
            continue
        g = d.get("geometry")
        c = np.asarray(g.coords if g is not None else [(H.nodes[u]["x"], H.nodes[u]["y"]), (H.nodes[v]["x"], H.nodes[v]["y"])], float)
        du = np.hypot(c[0, 0] - H.nodes[u]["x"], c[0, 1] - H.nodes[u]["y"])
        dv = np.hypot(c[0, 0] - H.nodes[v]["x"], c[0, 1] - H.nodes[v]["y"])
        H.add_edge(u, v, length=L, _c=c if du <= dv else c[::-1], _a=u)     # _c는 _a 쪽에서 시작

    # 2) 길을 짧은 조각으로 나눠 조각 중점으로 후보 검색 → 정확한 점-선분 거리로 확정
    E = list(H.edges(data=True))
    say(f"    도보 연결 준비: 길 {len(E):,}개를 {SNAP_PIECE_M}m 조각으로 나누는 중")
    n_pt = np.array([len(d["_c"]) for _, _, d in E])
    allc = np.vstack([d["_c"] for _, _, d in E])
    X, Y, _, _ = _local_xy(allc[:, 0], allc[:, 1])
    XY = np.c_[X, Y]
    owner = np.repeat(np.arange(len(E)), n_pt)
    last = np.cumsum(n_pt) - 1
    is_start = np.ones(len(XY), bool)
    is_start[last] = False
    i0 = np.where(is_start)[0]
    sa, sb, se = XY[i0], XY[i0 + 1], owner[i0]
    sl = np.hypot(*(sb - sa).T)
    cum = np.cumsum(sl)
    first_of_edge = np.r_[0, np.cumsum(n_pt - 1)[:-1]]
    edge_cum0 = np.r_[0, cum][first_of_edge]
    s0_seg = np.r_[0, cum[:-1]] - edge_cum0[se]
    e_len_geo = np.bincount(se, weights=sl, minlength=len(E))
    npc = np.maximum(1, np.ceil(sl / SNAP_PIECE_M).astype(int))
    rep = np.repeat(np.arange(len(sl)), npc)
    j = np.arange(len(rep)) - np.repeat(np.cumsum(npc) - npc, npc)
    t0, t1 = j / npc[rep], (j + 1) / npc[rep]
    d_ = (sb - sa)[rep]
    seg_p = sa[rep] + d_ * t0[:, None]
    seg_q = sa[rep] + d_ * t1[:, None]
    seg_s0 = s0_seg[rep] + sl[rep] * t0
    seg_e = se[rep]
    tree = cKDTree((seg_p + seg_q) / 2)

    names, rows = [], []
    for name, t in tables.items():
        names += [name] * len(t)
        rows.append(np.c_[t["경도"].values.astype(float), t["위도"].values.astype(float)])
    P_ll = np.vstack(rows)
    px, py, kx, ky = _local_xy(P_ll[:, 0], P_ll[:, 1])
    P = np.c_[px, py]
    _, cand = tree.query(P, k=min(SNAP_CANDIDATES, len(seg_e)))
    cand = np.atleast_2d(cand)
    A_, B_ = seg_p[cand], seg_q[cand]
    AB = B_ - A_
    ab2 = np.maximum((AB ** 2).sum(-1), 1e-12)
    tt = np.clip(((P[:, None, :] - A_) * AB).sum(-1) / ab2, 0, 1)
    proj = A_ + AB * tt[..., None]
    dist = np.hypot(*(P[:, None, :] - proj).transpose(2, 0, 1))
    best = dist.argmin(1)
    r = np.arange(len(P))
    piece = cand[r, best]
    gap = dist[r, best]
    e_idx = seg_e[piece]
    s_geo = seg_s0[piece] + tt[r, best] * np.hypot(*AB[r, best].T)
    frac = np.clip(s_geo / np.maximum(e_len_geo[e_idx], 1e-9), 0, 1)
    snap_xy = proj[r, best]

    # 3) 길마다 지점들을 위치 순서대로 끼워 넣기: _a — p1 — p2 — … — _b
    vid = [("_pt", i) for i in range(len(P))]
    order = np.lexsort((frac, e_idx))
    for k, grp in itertools.groupby(order, key=lambda i: e_idx[i]):
        grp = list(grp)
        u, v, d = E[k]
        a = d["_a"]
        b = v if a == u else u
        L = d["length"]
        H.remove_edge(u, v)
        prev, prev_f = a, 0.0
        for i in grp:
            H.add_node(vid[i], x=snap_xy[i, 0] / kx, y=snap_xy[i, 1] / ky)
            H.add_edge(prev, vid[i], length=max(frac[i] - prev_f, 0.0) * L)
            prev, prev_f = vid[i], frac[i]
        H.add_edge(prev, b, length=(1.0 - prev_f) * L)
    for _, _, d in H.edges(data=True):
        d.pop("_c", None); d.pop("_a", None)

    out, s = {}, 0
    for name, t in tables.items():
        out[name] = (list(vid[s:s + len(t)]), gap[s:s + len(t)])
        s += len(t)
    say(f"    도보 연결: 점 {len(P):,}개를 가장 가까운 길 위에 연결 — 점→길 거리 중앙값 {np.median(gap):.0f}m"
        + (f" (단지 {np.median(out['_apt'][1]):.0f}m)" if "_apt" in out else ""))
    return H, out


# ==================================================================
# 관계 테이블
# ==================================================================
def load_apartments():
    """좌표 붙은 실거래 → 단지 목록 [complex_id, 단지명, 구, 위도, 경도] (해제·군위군·LAST_YM 이후 제외)"""
    t = read_any(os.path.join(DATA_DIR, APT_FILE), dtype={"aptSeq": str})
    n0 = len(t)
    t = t[t["cdealType"].isna() & ~t["시군구명"].isin(EXCLUDE_GU)
          & (t["dealYear"] * 100 + t["dealMonth"] <= LAST_YM)]
    ok = t.dropna(subset=["위도", "경도"])
    mode = lambda s: s.round(6).mode().iloc[0]
    apt = t.groupby("aptSeq").agg(단지명=("aptNm", "first"), 구=("시군구명", "first"))
    apt = apt.join(ok.groupby("aptSeq").agg(위도=("위도", mode), 경도=("경도", mode)))
    print(f"    단지 목록: {APT_FILE} — 거래 {n0:,}건 중 {len(t):,}건 (해제·{', '.join(EXCLUDE_GU)} 제외, "
          f"{LAST_YM // 100}년 {LAST_YM % 100}월까지), 단지 {len(apt):,}곳")
    drop = apt[apt["위도"].isna()]
    if len(drop):
        print(f"    좌표 없는 단지 {len(drop)}곳 제외: " + ", ".join(f"{n}({c})" for c, n in drop["단지명"].items()))
    return apt.drop(drop.index).rename_axis("complex_id").reset_index()


def prepare():
    """단지·시설·도보 도로망 준비"""
    import osmnx as ox
    os.makedirs(REL_DIR, exist_ok=True)
    print("[1] 단지·시설 데이터")
    apt = load_apartments()
    infra = load_facilities()
    miss = infra["하수처리장"]["위도"].isna()
    if miss.any():
        print("    하수처리장 좌표 없음 → 제외: " + ", ".join(infra["하수처리장"].loc[miss, "이름"]))
        infra["하수처리장"] = infra["하수처리장"][~miss].reset_index(drop=True)
    ox.settings.use_cache = False                    # OSM 요청 캐시 폴더를 만들지 않음
    ox.settings.log_console = False
    ox.settings.requests_timeout = 600
    ox.settings.max_query_area_size = QUERY_TILE_M2
    print("\n[2] 도보 도로망")
    os.makedirs(GRAPH_DIR, exist_ok=True)
    Gw = get_walk_graph(ox, bbox_of(apt))
    if "버스정류장" not in infra:
        infra["버스정류장"] = load_osm_bus_stops(ox, bbox_of(apt))
    return apt, infra, Gw


def facility_dim(infra):
    """유형별 시설 표 → 시설ID가 채워진 시설 목록 (ID 없는 시설은 '유형_번호')"""
    dims = {}
    for t in ALL_TYPES:
        f = infra.get(t)
        if f is None or len(f) == 0:
            print(f"    {t}: 시설 없음 → 관계 테이블에서 제외")
            continue
        f = f.dropna(subset=["위도", "경도"]).reset_index(drop=True).copy()
        if "시설ID" not in f or f["시설ID"].isna().all():
            f["시설ID"] = [f"{t}_{i:05d}" for i in range(len(f))]
        f["시설ID"] = f["시설ID"].fillna(pd.Series([f"{t}_{i:05d}" for i in range(len(f))]))
        if t == "도시철도역":            # 출구 단위 → 역 단위 키 ('범어역 8번 출구' → '범어역')
            f["시설ID"] = "역_" + f["이름"].str.replace(r"\s*\d+번 출구$", "", regex=True).str.replace(
                r"\(출입구 정보 없음, 역 중심\)$", "", regex=True)
        dims[t] = f
    return dims


def build(apt, dims, Gw):
    print("\n[3] 단지·시설을 가장 가까운 길 위에 연결")
    H, snapped = attach_points(Gw, {"_apt": apt, **{f"f:{t}": f for t, f in dims.items()}})
    apt_nodes, apt_gap = snapped["_apt"]
    at = {}                                          # 교차점 → [(유형, 시설 번호)]
    for t in [t for t in dims if t not in STRAIGHT_RANGE_M]:
        for i, n in enumerate(snapped[f"f:{t}"][0]):
            at.setdefault(n, []).append((t, i))
    gaps = {t: snapped[f"f:{t}"][1] for t in dims}

    # 최근접형: 범위 밖이어도 가장 가까운 1곳 (다중 출발 다익스트라)
    nearest = {}
    for t in [t for t in NEAREST_TYPES if t in dims and NEAREST_GUARANTEE and t not in STRAIGHT_RANGE_M]:
        dist, lab = nearest_labeled(H, snapped[f"f:{t}"][0], gaps[t], weight="length")
        m = np.array([dist.get(n, np.nan) for n in apt_nodes]) + apt_gap
        nearest[t] = (np.array([lab.get(n, -1) for n in apt_nodes]), m / WALK_SPEED_MPS / 60)

    max_min = max([REL_CUTOFF_MIN] + list(REL_CUTOFF_BY_TYPE.values()))
    print(f"\n[4] 단지별 도보 {max_min}분 탐색 → 관계 행 만들기 (범위: 기본 {REL_CUTOFF_MIN}분"
          + (f", {REL_CUTOFF_BY_TYPE}" if REL_CUTOFF_BY_TYPE else "") + ")")
    cutoff_m = max_min * 60 * WALK_SPEED_MPS
    rows, cache, t0 = [], {}, time.time()
    for k, (cid, node, g0) in enumerate(zip(apt["complex_id"], apt_nodes, apt_gap)):
        if node not in cache:
            cache = {node: nx.single_source_dijkstra_path_length(H, node, cutoff=cutoff_m, weight="length")}
        reach = cache[node]
        typ, idx, meters = [], [], []
        for n, d in reach.items():
            for t, i in at.get(n, ()):
                typ.append(t); idx.append(i); meters.append(d + gaps[t][i] + g0)
        r = pd.DataFrame({"complex_id": cid, "시설유형": typ, "_i": idx,
                          "도보_분": np.round(np.array(meters, float) / WALK_SPEED_MPS / 60, 1)})
        lim = r["시설유형"].map(lambda t: REL_CUTOFF_BY_TYPE.get(t, REL_CUTOFF_MIN))
        r = r[r["도보_분"] <= lim]
        extra = []
        for t, (lab, mins) in nearest.items():           # 최근접 1곳 보장
            if lab[k] >= 0 and not ((r["시설유형"] == t) & (r["_i"] == lab[k])).any():
                extra.append({"complex_id": cid, "시설유형": t, "_i": int(lab[k]), "도보_분": round(float(mins[k]), 1)})
        rows.append(pd.concat([r, pd.DataFrame(extra)], ignore_index=True) if extra else r)
        if (k + 1) % 200 == 0:
            print(f"    {k + 1:,}/{len(apt):,} 단지 ({time.time() - t0:.0f}초)")
    rel = pd.concat(rows, ignore_index=True)
    rel["기준"] = "도보"

    # 직선거리 범위 유형 (도로망과 무관)
    from sklearn.neighbors import BallTree
    for t, rng_m in STRAIGHT_RANGE_M.items():
        if t not in dims:
            continue
        tree = BallTree(np.radians(dims[t][["위도", "경도"]].values), metric="haversine")
        ind, dist = tree.query_radius(np.radians(apt[["위도", "경도"]].values), r=rng_m / EARTH_R_M,
                                      return_distance=True)
        add = [pd.DataFrame({"complex_id": cid, "시설유형": t, "_i": ii, "도보_분": np.nan, "기준": "직선"})
               for cid, ii in zip(apt["complex_id"], ind) if len(ii)]
        if add:
            rel = pd.concat([rel] + add, ignore_index=True)
        print(f"    {t}: 직선 {rng_m:,}m 범위 — 관계 {sum(len(i) for i in ind):,}행")

    # 시설 정보 붙이기
    parts = []
    for t, g in rel.groupby("시설유형"):
        f = dims[t]
        ii = g["_i"].to_numpy(dtype=np.int64)
        g = g.assign(시설ID=f["시설ID"].to_numpy(dtype=object)[ii], 시설명=f["이름"].to_numpy(dtype=object)[ii],
                     _flat=f["위도"].to_numpy(dtype=float)[ii], _flon=f["경도"].to_numpy(dtype=float)[ii])
        if t == "도시철도역":                              # 역 단위: 가장 가까운 출구만
            g = g.sort_values("도보_분").drop_duplicates(["complex_id", "시설ID"])
        parts.append(g)
    rel = pd.concat(parts, ignore_index=True)
    pos = apt.set_index("complex_id")
    alat, alon = rel["complex_id"].map(pos["위도"]).values, rel["complex_id"].map(pos["경도"]).values
    rel["직선거리_m"] = haversine_m(alat, alon, rel["_flat"].values, rel["_flon"].values).round(0)
    rel = rel.drop(columns=["_i", "_flat", "_flon"])
    rel["구간"] = time_bin(rel["도보_분"]).values
    st = rel["기준"] == "직선"
    if st.any():
        labs = [f"{b}m이내" for b in STRAIGHT_BINS_M]
        rel.loc[st, "구간"] = pd.cut(rel.loc[st, "직선거리_m"], [-np.inf] + STRAIGHT_BINS_M, labels=labs).astype(str).values
    rel["_정렬"] = rel["도보_분"].fillna(rel["직선거리_m"])
    rel = rel.sort_values(["complex_id", "시설유형", "_정렬"])
    rel["순위"] = rel.groupby(["complex_id", "시설유형"]).cumcount() + 1
    rel = rel[["complex_id", "시설유형", "시설ID", "시설명", "기준", "도보_분", "직선거리_m", "구간", "순위"]].reset_index(drop=True)

    dim_f = pd.concat([f.drop(columns=["시설명"], errors="ignore")
                       .assign(시설유형=t, **{"도로연결(m)": gaps[t].round(0)}).rename(columns={"이름": "시설명"})
                       for t, f in dims.items()], ignore_index=True)
    first = ["시설유형", "시설ID", "시설명", "위도", "경도", "도로연결(m)"]
    dim_f = dim_f[first + [c for c in dim_f.columns if c not in first]]
    dim_a = apt[["complex_id", "단지명", "구", "위도", "경도"]].assign(**{"도로연결(m)": apt_gap.round(0)})
    return rel, dim_f, dim_a


def save(rel, dim_f, dim_a):
    print("\n[5] 저장")
    for name, df in [("rel_단지_시설", rel), ("dim_시설", dim_f), ("dim_단지", dim_a)]:
        p = os.path.join(REL_DIR, f"{name}.csv")
        df.to_csv(p, index=False, encoding="utf-8-sig")
        print(f"    {p}  ({len(df):,}행)")
    fac = (rel.pivot_table(index=["시설유형", "시설ID", "시설명"], columns="구간", values="complex_id",
                           aggfunc="nunique", fill_value=0))
    order = TIME_LABELS + [f"{b}m이내" for b in STRAIGHT_BINS_M]
    fac = fac[[c for c in order if c in fac.columns]]
    fac["권역_단지수"] = rel.groupby(["시설유형", "시설ID", "시설명"])["complex_id"].nunique()
    fac = fac.reset_index()
    fac.columns.name = None
    p = os.path.join(REL_DIR, "fac_권역_요약.csv")
    fac.to_csv(p, index=False, encoding="utf-8-sig")
    print(f"    {p}  ({len(fac):,}행, 시설마다 구간별 단지 수 — 구간은 누적 아님)")
    print("\n    [유형별 관계 행 수 / 단지당 평균]")
    s = rel.groupby("시설유형").agg(행수=("complex_id", "size"), 단지수=("complex_id", "nunique"))
    n_apt = dim_a["complex_id"].nunique()
    s["단지당_평균"] = (s["행수"] / n_apt).round(1)
    s["범위안_시설없는_단지"] = n_apt - s["단지수"]
    s["범위"] = [f"직선 {STRAIGHT_RANGE_M[t]:,}m" if t in STRAIGHT_RANGE_M else f"도보 {REL_CUTOFF_BY_TYPE.get(t, REL_CUTOFF_MIN)}분"
                for t in s.index]
    print(s.sort_values("행수", ascending=False).to_string())


def count_within(rel, dim_a, facility_type, minutes):
    """단지별 'N분 안 시설 수' (시설이 없는 단지는 0)"""
    c = rel[(rel["시설유형"] == facility_type) & (rel["도보_분"] <= minutes)].groupby("complex_id").size()
    return c.reindex(dim_a["complex_id"], fill_value=0)


def print_examples(rel, dim_a):
    print("\n    [검증·활용 예]")
    e = rel[(rel["시설유형"] == "초등학교") & (rel["순위"] == 1)][["complex_id", "시설명", "도보_분", "구간"]]
    print("    범위 안 가장 가까운 초등학교 (앞 3행):\n" + e.head(3).to_string(index=False))
    c = count_within(rel, dim_a, "입시학원", 10)
    print(f"    도보 10분이내 입시학원 수 중앙값: {c.median():.0f} (0곳인 단지 {(c == 0).sum()}개)")
    w = rel[(rel["시설유형"] == "초등학교") & (rel["도보_분"] <= 10)].groupby("시설ID")["complex_id"].nunique()
    print(f"    초등학교 도보 10분 권역 단지 수: 중앙값 {w.median():.0f}, 최대 {w.max()}")


def main():
    apt, infra, Gw = prepare()
    dims = facility_dim(infra)
    rel, dim_f, dim_a = build(apt, dims, Gw)
    save(rel, dim_f, dim_a)
    print_examples(rel, dim_a)
    print("\n완료.")


if __name__ == "__main__":
    main()
