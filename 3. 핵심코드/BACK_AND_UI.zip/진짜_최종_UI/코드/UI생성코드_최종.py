"""
1번 방안 (실시간 묶음) HTML 만들기 — 새 설계 기준

  파이썬에서 하는 일 (이 파일)
    1) 단지별 시설 정보: 거점 시설 7종 도보 시간, 밀집 시설 4종 10분 안 개수, 유흥주점 10분 안 개수, 하수처리장 직선거리
    2) 가격 모델 2개 학습 (LightGBM, 예측 대상 = log(㎡당 가격))
         모델 A (집·아파트만 봄): 전용면적, 층, 상대층(거래 층 ÷ 단지 최고층), 단지 최고층, 연식, 거래 시점
                           (로얄층·기피층 + 고층 단지 몫은 아파트 몫 → 동네 프리미엄에서 뺌)
         모델 B (집 + 시설): 모델 A 정보 + 위 1)의 시설 정보
       - 위치(구·동·좌표·단지 ID)는 넣지 않음
       - 거래마다 예측값은 "그 단지를 빼고 학습한 모델"로 구함 (단지 단위 5겹 교차검증)
       - 검증: 단지 단위 교차검증 R², 시간 분할(2023~2025 학습 → 2026 평가) R²
    3) ② 계산용 곡선: 모델 B에서 시설 값 하나만 바꿨을 때 예측이 얼마나 바뀌는지 (부분 의존 곡선)
    4) 시세 지수: 모델 A에서 거래 시점만 바꿨을 때의 예측 (예산 비교 때 오래된 거래 보정용)

  브라우저에서 하는 일 (맨 아래 UI_TEMPLATE)
    1) 조건 필터: 예산 · 평형 · 거점 N분 · 밀집 M개 이상 · 유흥주점 N개 이하 · 하수처리장 N km 이상
    2) 묶음: 같은 구 안에서 직선거리 2km 완전 연결 군집. 이름 = "구 법정동 일대"
       (여러 법정동에 걸치면 거래가 가장 많은 법정동)
    3) 고정효과 회귀: (실제 − 모델 예측) = 묶음 몫 + 분기 몫. 후보 단지의 모든 평형 거래,
       단위 = 단지×분기 칸 (무게 n/(n+1)). 기준 = 거래가 가장 많은 묶음
    4) 총 프리미엄(모델 A 기준), ③(모델 B 기준), ②(고른 조건 시설만 0% 묶음 평균값으로 바꾼 모델 B 반사실 예측), ① = 나머지
       0% = 거래 10건 이상 묶음 중 가장 싼 곳. 묶음 2개 이상이면 계산, 1개면 프리미엄 없음
       참고 = 묶음의 단지당 평균 거래 2건 미만
    5) 불확실성 범위: 단지 부트스트랩 100회, 80% 범위

입력 (입력데이터/ 폴더): dim_단지.csv, rel_단지_시설.csv, daegu_apt_trades.csv (해제·직거래·군위군 제외),
                              apt_complex_max_floors_final.csv (건축물대장 단지 최고층)
출력: 결과/동네프리미엄_실시간.html
"""
import json
import os

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

# 폴더 구성: 코드/ (이 파일, vendor/leaflet.* 는 있으면 사용) · 입력데이터/ · 결과/
CODE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(CODE_DIR)                    # 동네UI(NEW) 폴더
DATA = os.path.join(BASE_DIR, "입력데이터")
VENDOR = os.path.join(CODE_DIR, "vendor")                 # leaflet.css·leaflet.js (있으면 화면 파일 안에 넣음)
LEAFLET_CDN = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet"   # vendor/ 가 없을 때
OUT = os.path.join(BASE_DIR, "결과", "동네프리미엄_최종.html")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

FACS = ["초등학교", "중학교", "고등학교", "도시철도역", "대형마트", "종합병원", "공원"]
DENSE = ["편의점", "의원", "입시학원", "음식점"]
BAND_MIN = {"5분이내": 5, "10분이내": 10, "15분이내": 15, "20분이내": 20}
NONE_NAME = "20분 안에 없음"
NO_FAC_MIN = 25.0        # 20분 안에 시설이 없을 때 모델에 넣는 도보 시간
NO_SEWER_M = 3500.0      # 3km 안에 하수처리장이 없을 때 모델에 넣는 거리
SEED = 0

# ── 단지 ──
a = pd.read_csv(os.path.join(DATA, "dim_단지.csv"), encoding="utf-8-sig")
a["complex_id"] = a["complex_id"].astype(str)
cidx = {c: i for i, c in enumerate(a["complex_id"])}
N = len(a)

r = pd.read_csv(os.path.join(DATA, "rel_단지_시설.csv"), encoding="utf-8-sig",
                usecols=["complex_id", "시설유형", "시설ID", "시설명", "기준", "도보_분", "직선거리_m", "구간", "순위"])
r["complex_id"] = r["complex_id"].astype(str)
r = r[r["complex_id"].isin(cidx)]
r["ci"] = r["complex_id"].map(cidx)

# 거점 시설: 가장 가까운 곳 (순위 1)
near = r[r["시설유형"].isin(FACS)].sort_values("순위").drop_duplicates(["complex_id", "시설유형"])
near["표시명"] = np.where(near["시설유형"] == "도시철도역", near["시설ID"].str.replace(r"^역_", "", regex=True), near["시설명"])
fac, names = {}, {}
for f in FACS:
    s = near[near["시설유형"] == f]
    ids = sorted(s["시설ID"].unique())
    id_name = s.drop_duplicates("시설ID").set_index("시설ID")["표시명"]
    names[f] = [id_name[i] for i in ids] + [NONE_NAME]
    id_idx = {i: k for k, i in enumerate(ids)}
    n = np.full(N, len(ids)); b = np.full(N, 99); t = np.full(N, 99.0)
    rows = s["ci"].to_numpy()
    n[rows] = s["시설ID"].map(id_idx).to_numpy(); b[rows] = s["구간"].map(BAND_MIN).to_numpy(); t[rows] = s["도보_분"].round(1).to_numpy()
    fac[f] = {"n": n.tolist(), "b": b.tolist(), "t": t.tolist()}

# 밀집 시설 + 유흥주점: 걸어서 10분 안 개수
in10 = r[(r["기준"] == "도보") & (r["도보_분"] <= 10)]
cnt = in10.groupby(["ci", "시설유형"]).size().unstack(fill_value=0)
dense = {f: cnt.get(f, pd.Series(dtype=int)).reindex(range(N)).fillna(0).astype(int).tolist() for f in DENSE + ["유흥주점"]}

# 하수처리장: 가장 가까운 곳 직선거리 (3km 안만 있음 → 없으면 null = 3km 넘음)
sw = r[r["시설유형"] == "하수처리장"].sort_values("직선거리_m").drop_duplicates("ci")
sewer = np.full(N, np.nan); sewer[sw["ci"].to_numpy()] = sw["직선거리_m"].to_numpy()

# 단지별 모델 입력 (시설). 모델 컬럼 이름은 영문(t0~t6, n0~n4)으로, 화면용 이름은 COL에
COL = {}
CF = pd.DataFrame(index=range(N))
for i, f in enumerate(FACS):
    CF[f"t{i}"] = np.where(np.array(fac[f]["b"]) == 99, NO_FAC_MIN, np.array(fac[f]["t"])); COL[f"t_{f}"] = f"t{i}"
for j, f in enumerate(DENSE + ["유흥주점"]):
    CF[f"n{j}"] = dense[f]; COL[f"n_{f}"] = f"n{j}"
CF["sewer_m"] = np.where(np.isnan(sewer), NO_SEWER_M, sewer); COL["sewer_m"] = "sewer_m"

# ── 거래 ──
tr = pd.read_csv(os.path.join(DATA, "daegu_apt_trades.csv"), encoding="utf-8-sig", low_memory=False,
                 dtype={"aptDong": str})
tr["aptSeq"] = tr["aptSeq"].astype(str)
n_raw = len(tr)
# 해제 거래·직거래(가족 간 거래 등 시세와 다른 가격)·군위군 제외
tr = tr[tr["cdealType"].isna() & (tr["dealingGbn"] != "직거래") & (tr["시군구명"] != "군위군")
        & (tr["excluUseAr"] > 0) & (tr["dealAmount_만원"] > 0) & tr["aptSeq"].isin(cidx)].reset_index(drop=True)
print(f"거래 {n_raw:,}건 → {len(tr):,}건 (해제·직거래·군위군 제외)")
tr["ci"] = tr["aptSeq"].map(cidx)
tr["m"] = (tr["dealYear"] - 2023) * 12 + tr["dealMonth"] - 1
tr["age"] = (tr["dealYear"] - tr["buildYear"]).clip(lower=0)
tr["lp"] = np.log(tr["dealAmount_만원"] / tr["excluUseAr"])

# ── 최고층 → 상대층 (층 ÷ 최고층) ──
#   건축물대장 단지 최고층 (apt_complex_max_floors_final.csv)
#   (동별 최고층과 비교했을 때 미래 거래 예측·층 몫 걸러내기가 더 좋았음)
#   거래 층이 최고층보다 높게 적힌 경우(대장 오류 등)는 최고층 = 거래 층으로
mx_c = pd.read_csv(os.path.join(DATA, "apt_complex_max_floors_final.csv"), encoding="utf-8-sig", dtype={"aptSeq": str})
by_cx = tr["aptSeq"].map(mx_c.drop_duplicates("aptSeq").set_index("aptSeq")["단지최고층"])
fl = tr["floor"].clip(lower=1).astype(float)
max_fl = by_cx.fillna(tr.groupby("aptSeq")["floor"].transform("max"))   # 대장에 없으면 거래된 가장 높은 층
tr["max_floor"] = np.maximum(max_fl, fl)
tr["rel_floor"] = (fl / tr["max_floor"]).round(4)
print(f"최고층: 건축물대장 단지 {by_cx.notna().mean():.1%} · 거래 기록 {by_cx.isna().mean():.1%}")

# 층: 로얄층·기피층은 단지 높이에 따라 다름 (5층 건물 탑층은 기피, 30층 건물 탑층은 선호)
#   → 층 + 상대층 + 단지 최고층을 같이 넣어 모델이 높이별 선호층을 배우게 함
#   고층 단지라서 비싼 몫은 "아파트" 몫이므로 동네 프리미엄에서 빠지는 것이 맞음
XA = pd.DataFrame({"area": tr["excluUseAr"], "floor": tr["floor"], "rel_floor": tr["rel_floor"],
                   "max_floor": tr["max_floor"], "age": tr["age"], "m": tr["m"]})
XB = pd.concat([XA, CF.iloc[tr["ci"].to_numpy()].reset_index(drop=True)], axis=1)
y = tr["lp"].to_numpy()
PARAMS = dict(n_estimators=700, learning_rate=0.04, num_leaves=63, min_child_samples=30,
              subsample=0.8, subsample_freq=1, colsample_bytree=0.8, random_state=SEED, verbose=-1)


def r2(yt, yp): return 1 - ((yt - yp) ** 2).sum() / ((yt - yt.mean()) ** 2).sum()
def err_pct(yt, yp): return float(np.mean(np.abs(np.expm1(yp - yt))) * 100)


def oof(X):
    """단지 단위 5겹: 각 거래의 예측은 그 단지를 빼고 학습한 모델로"""
    p = np.zeros(len(X))
    for trn, tst in GroupKFold(5).split(X, y, tr["ci"]):
        p[tst] = lgb.LGBMRegressor(**PARAMS).fit(X.iloc[trn], y[trn]).predict(X.iloc[tst])
    return p


def time_split(X):
    """시간 분할: 2023~2025 학습 → 2026 평가 (채점용. 실제 계산에 쓰는 모델은 전체 기간으로 학습)"""
    trn = (tr["dealYear"] <= 2025).to_numpy()
    tst = (tr["dealYear"] == 2026).to_numpy()
    p = lgb.LGBMRegressor(**PARAMS).fit(X[trn], y[trn]).predict(X[tst])
    return r2(y[tst], p)


print("모델 학습 중 (몇 분 걸릴 수 있음)…")
pA, pB = oof(XA), oof(XB)
val = {
    "A": {"r2": round(r2(y, pA), 3), "err": round(err_pct(y, pA), 1), "r2_time": round(time_split(XA), 3)},
    "B": {"r2": round(r2(y, pB), 3), "err": round(err_pct(y, pB), 1), "r2_time": round(time_split(XB), 3)},
}
print("검증:", val)

# 전체 데이터로 학습한 모델
mA = lgb.LGBMRegressor(**PARAMS).fit(XA, y)
mB = lgb.LGBMRegressor(**PARAMS).fit(XB, y)


def pd_curve(model, X, col, grid):
    out = []
    for g in grid:
        Z = X.copy(); Z[col] = g
        out.append(float(model.predict(Z).mean()))
    base = out[0]
    return [round(v - base, 5) for v in out]


# 모델 B 나무를 HTML에 넣음 → 브라우저가 "고른 조건 시설만 가장 싼 동네 수준으로 바꿨을 때" 예측을 직접 계산 (②)
#   노드: nf = 나눌 컬럼 번호, th = 기준값 (값 <= 기준이면 왼쪽), lc/rc = 자식 (0 이상 = 노드, 음수 = ~잎 번호)
def export_trees(model):
    T = {"root": [], "noff": [], "loff": [], "nf": [], "th": [], "lc": [], "rc": [], "lv": []}
    for info in model.booster_.dump_model()["tree_info"]:
        nodes, leaves = [], []

        def walk(nd):
            if "split_index" not in nd:
                leaves.append(nd["leaf_value"]); return ~(len(leaves) - 1)
            assert nd["decision_type"] == "<=" and nd["missing_type"] in ("None", "NaN"), nd["decision_type"]
            i = len(nodes); nodes.append(None)
            lc, rc = walk(nd["left_child"]), walk(nd["right_child"])
            nodes[i] = (nd["split_feature"], float(nd["threshold"]), lc, rc)
            return i

        T["root"].append(walk(info["tree_structure"]))
        T["noff"].append(len(T["nf"])); T["loff"].append(len(T["lv"]))
        for nf, th, lc, rc in nodes:
            T["nf"].append(nf); T["th"].append(th); T["lc"].append(lc); T["rc"].append(rc)
        T["lv"].extend(leaves)
    return T


def predict_trees(T, X):
    X = np.asarray(X, float); out = np.zeros(len(X))
    for k, root in enumerate(T["root"]):
        no, lo = T["noff"][k], T["loff"][k]
        for r in range(len(X)):
            n = root
            while n >= 0:
                j = no + n
                n = T["lc"][j] if X[r, T["nf"][j]] <= T["th"][j] else T["rc"][j]
            out[r] += T["lv"][lo + ~n]
    return out


treesB = export_trees(mB)
pBf = mB.predict(XB)          # 실제 시설 그대로의 모델 B 예측 (②의 출발점)
chk = XB.sample(300, random_state=SEED)
assert np.allclose(predict_trees(treesB, chk), mB.predict(chk), atol=1e-9), "나무 내보내기 확인 실패"
print(f"모델 B 나무 {len(treesB['root'])}개 · 노드 {len(treesB['nf']):,}개 내보냄 (예측 일치 확인)")

# 시세 지수 (월별): 모델 A에서 거래 시점만 바꿈
months = list(range(int(tr["m"].min()), int(tr["m"].max()) + 1))
sA = XA.sample(min(3000, len(XA)), random_state=SEED)
idx = pd_curve(mA, sA, "m", months)

# 단지 법정동 (거래 자료의 umdNm, 단지마다 하나) → 묶음 이름 "구 법정동 일대"에 씀
umd = tr.drop_duplicates("aptSeq").set_index("aptSeq")["umdNm"]
apts = {
    "name": a["단지명"].tolist(), "gu": a["구"].tolist(),
    "dong": [str(umd.get(c, "")) if pd.notna(umd.get(c, None)) else "" for c in a["complex_id"]],
    "lat": a["위도"].round(6).tolist(), "lon": a["경도"].round(6).tolist(),
    "fac": fac, "dense": dense,
    "sewer": [None if np.isnan(v) else int(v) for v in sewer],
}
trades = {
    "c": tr["ci"].astype(int).tolist(), "m": tr["m"].astype(int).tolist(), "d": tr["dealDay"].astype(int).tolist(),
    "ar": (tr["excluUseAr"] * 100).round().astype(int).tolist(), "fl": tr["floor"].astype(int).tolist(),
    "age": tr["age"].astype(int).tolist(), "pr": tr["dealAmount_만원"].astype(int).tolist(),
    "lp": (tr["lp"] * 1e4).round().astype(int).tolist(),
    "pA": (pA * 1e4).round().astype(int).tolist(), "pB": (pB * 1e4).round().astype(int).tolist(),
    "mx": tr["max_floor"].astype(int).tolist(),                 # 단지 최고층 (모델 B 입력 재현용)
    "rf": (tr["rel_floor"] * 1e4).round().astype(int).tolist(),  # 상대층 × 10000
    "area": tr["excluUseAr"].astype(float).tolist(),             # 전용면적 원값 (모델 B 입력 재현용)
    "pBf": (pBf * 1e6).round().astype(np.int64).tolist(),       # 전체 데이터 모델 B 예측 (②용)
}
ymin, ymax = int(tr["dealYear"].min()), int(tr["dealYear"].max())
meta = {"facs": FACS, "dense": DENSE, "names": names, "n_trades": len(tr), "val": val,
        "treesB": treesB, "colB": list(XB.columns), "colKey": {v: k for k, v in COL.items()}, "idx": {"m0": months[0], "v": idx}, "no_fac_min": NO_FAC_MIN, "no_sewer_m": NO_SEWER_M,
        "months": f"{ymin}-{int(tr.loc[tr['dealYear'] == ymin, 'dealMonth'].min()):02d} ~ "
                  f"{ymax}-{int(tr.loc[tr['dealYear'] == ymax, 'dealMonth'].max()):02d}"}

# ==================================================================
# 화면 (UI) — app.py 화면으로 교체
# ==================================================================
# 화면용 추가 정보: 지도에 그릴 도시철도 노선 (모델·계산과 무관). 단지 법정동은 위 백엔드의 apts["dong"] 사용
st_path = os.path.join(DATA, "도시철도역좌표.csv")
if os.path.exists(st_path):
    st = pd.read_csv(st_path, encoding="utf-8-sig")
    meta["stations"] = {"name": st["이름"].tolist(), "line": st["분류"].tolist(),
                        "lat": st["위도"].round(5).tolist(), "lon": st["경도"].round(5).tolist()}


def build_html():
    html = UI_TEMPLATE
    for key, obj in [("APTS", apts), ("TRADES", trades), ("META", meta)]:
        html = html.replace(f"/*__{key}__*/null", json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    css, js = os.path.join(VENDOR, "leaflet.css"), os.path.join(VENDOR, "leaflet.js")
    if os.path.exists(css) and os.path.exists(js):          # 지도 라이브러리를 파일 안에 넣음 (오프라인 가능)
        html = html.replace("/*__LEAFLET_CSS__*/", open(css, encoding="utf-8").read())
        html = html.replace("/*__LEAFLET_JS__*/", open(js, encoding="utf-8").read())
    else:                                                    # vendor/ 가 없으면 인터넷에서 불러옴
        html = html.replace("/*__LEAFLET_CSS__*/", "")
        html = html.replace('<meta charset="utf-8">', f'<meta charset="utf-8">\n<link rel="stylesheet" href="{LEAFLET_CDN}.min.css">', 1)
        html = html.replace("<script>/*__LEAFLET_JS__*/</script>", f'<script src="{LEAFLET_CDN}.min.js"></script>')
        print("vendor/leaflet.* 없음 → 지도 라이브러리는 인터넷에서 불러옴")
    # 배경 지도 (키 필요 없음)
    #   localhost로 열면 OpenStreetMap 공식 타일
    #   더블클릭(file://)으로 열면 OSM 공식 서버가 막으므로(Referer 없음) OSM 프랑스 타일로 자동 전환
    tile = '"https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"'
    carto = ' &copy; <a href="https://carto.com/attributions">CARTO</a>'
    assert tile in html and carto in html and 'subdomains:"abcd"' in html, "화면 템플릿에서 배경 지도 설정을 찾지 못함"
    html = (html.replace(tile, '(location.protocol==="file:"?"https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png"'
                               ':"https://tile.openstreetmap.org/{z}/{x}/{y}.png")')
                .replace(carto, "").replace('subdomains:"abcd"', 'subdomains:"abc"', 1))
    return '<!doctype html>\n<html lang="ko">\n' + html + "\n</html>\n"


# 화면 템플릿 (app.py 의 UI_TEMPLATE 그대로)
#   자리표시: /*__APTS__*/null, /*__TRADES__*/null, /*__META__*/null, /*__LEAFLET_CSS__*/, /*__LEAFLET_JS__*/
UI_TEMPLATE = r'''<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>동네 프리미엄 조건 찾기</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;600;700;800&display=swap">
<style>
/* Layout: 컴퓨터 화면 — 왼쪽은 아이폰 설정 앱 같은 조건 패널(고정), 오른쪽은 결과(요약 → 목록·지도·상세 → 놓친 매물 → 동네별 프리미엄 → 계산 방법). 1100px 아래는 한 줄로 쌓임 */
:root{
  --bg:#F2F2F7; --cell:#FFFFFF; --sep:#C6C6C8; --label:#000000; --label2:#3C3C43; --label3:#6C6C70; --fill:#E9E9EB;
  --blue:#007AFF; --green:#34C759; --track:#E5E5EA; --pill:#8E8E93; --pillfill:#FFFFFF; --map:#E8E8ED; --paper:#F6F2E8; --fiber:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='180' height='180'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.75 .12' numOctaves='3' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .55  0 0 0 0 .5  0 0 0 0 .42  0 0 0 .55 -.18'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
  --p0:#8E8E93; --p1:#FF9F0A; --p2:#FF6B00; --p3:#E5332A; --save:#248A3D;
  --font:-apple-system,BlinkMacSystemFont,"SF Pro Text","Apple SD Gothic Neo","Noto Sans KR","Malgun Gothic",sans-serif;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#000000; --cell:#1C1C1E; --sep:#38383A; --label:#FFFFFF; --label2:#EBEBF5; --label3:#98989F; --fill:#2C2C2E;
  --blue:#0A84FF; --green:#30D158; --track:#39393D; --pill:#3A3A3C; --pillfill:#F2F2F7; --map:#141416; --paper:#1D1B18; --fiber:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='180' height='180'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.75 .12' numOctaves='3' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .9  0 0 0 0 .88  0 0 0 0 .82  0 0 0 .35 -.12'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
  --p0:#98989F; --p1:#FFB340; --p2:#FF7A1A; --p3:#FF453A; --save:#30D158; color-scheme:dark}}
:root[data-theme="dark"]{
  --bg:#000000; --cell:#1C1C1E; --sep:#38383A; --label:#FFFFFF; --label2:#EBEBF5; --label3:#98989F; --fill:#2C2C2E;
  --blue:#0A84FF; --green:#30D158; --track:#39393D; --pill:#3A3A3C; --pillfill:#F2F2F7; --map:#141416; --paper:#1D1B18; --fiber:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='180' height='180'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.75 .12' numOctaves='3' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .9  0 0 0 0 .88  0 0 0 0 .82  0 0 0 .35 -.12'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
  --p0:#98989F; --p1:#FFB340; --p2:#FF7A1A; --p3:#FF453A; --save:#30D158; color-scheme:dark}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
[hidden]{display:none!important}
/* 설명 보기를 끄면(기본) 작은 설명 글씨는 숨기고 큰 글씨만 */
body:not(.explain) :is(.foot,.sub,.ex,.budget>span,.chead>span:not(#listSub),.top .lede,#foot){display:none!important}
.explain-sw{display:inline-flex;align-items:center;gap:10px;font-size:15px;font-weight:600;cursor:pointer;user-select:none}
.explain-sw input{position:absolute;opacity:0;width:1px;height:1px}
.explain-sw .knob{position:relative;width:46px;height:28px;border-radius:14px;background:var(--fill,rgba(120,120,128,.24));transition:background .2s}
.explain-sw .knob::after{content:"";position:absolute;top:2px;left:2px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 2px 5px rgba(0,0,0,.2);transition:transform .2s}
.explain-sw input:checked+.knob{background:#34C759}
.explain-sw input:checked+.knob::after{transform:translateX(18px)}
.explain-sw input:focus-visible+.knob{outline:2px solid var(--blue);outline-offset:2px}
body{background:var(--bg);color:var(--label);font-family:var(--font);font-size:16px;line-height:1.4;letter-spacing:-.01em;
  padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:0 40px}
button,input{font:inherit;color:inherit}
:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
.wrap{max-width:1500px;margin:0 auto}
.top{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;padding:20px 4px 16px}
.top h1{margin:0;font-size:34px;font-weight:700;letter-spacing:-.02em;line-height:1.1}
.top p{margin:4px 0 0;color:var(--label3);font-size:15px}
.layout{display:grid;grid-template-columns:396px minmax(0,1fr);gap:16px;align-items:start}
.layout.closed{grid-template-columns:minmax(0,1fr)}
.layout.closed .panel{display:none}
.layout.closed .main{animation:slidein .22s ease-out}
@keyframes slidein{from{opacity:.6;transform:translateX(-12px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.layout.closed .main{animation:none}}
.sidebtn{display:inline-flex;align-items:center;gap:8px;height:40px;padding:0 14px 0 10px;border-radius:12px;border:0;background:var(--cell);color:var(--label);font-size:14px;font-weight:600;cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,.06);margin-bottom:2px;white-space:nowrap}
.sidebtn svg{width:22px;height:22px}
.sidebtn:hover{background:var(--fill)}
.sidebtn[aria-expanded="false"]{background:var(--blue);color:#fff}
.sidebtn .chips{font-weight:500;opacity:.85}
@media (max-width:1100px){.layout,.layout.closed{grid-template-columns:minmax(0,1fr)}.layout.closed .panel{display:none}}

/* ── 조건 패널 (아이폰 설정) ── */
.panel{position:sticky;top:16px;max-height:calc(100vh - 32px);overflow-y:auto;padding:0 16px 20px 0;scrollbar-width:thin;scrollbar-gutter:stable}
@media (max-width:1100px){.panel{position:static;max-height:none}}
.group{background:var(--cell);border-radius:12px;overflow:hidden}
.ghead{font-size:13px;color:var(--label3);margin:22px 16px 7px}
.ghead:first-child{margin-top:0}
.foot{font-size:13px;color:var(--label3);margin:7px 16px 0;line-height:1.4}
.row{display:flex;align-items:center;gap:12px;min-height:44px;padding:10px 16px;position:relative;width:100%;border:0;background:none;text-align:left}
.row+.row::before,.extra+.row::before{content:"";position:absolute;top:0;left:16px;right:0;height:.5px;background:var(--sep)}
.row.ic+.row::before,.extra+.row.ic::before{left:58px}
.row .t{flex:1;min-width:0}
.row .v{color:var(--label3);white-space:nowrap;font-variant-numeric:tabular-nums}
.chev{width:8px;height:14px;color:#C4C4C7;flex:none}
button.row{cursor:pointer}
button.row:hover{background:color-mix(in srgb,var(--fill) 50%,transparent)}
button.row[aria-current="true"]{background:color-mix(in srgb,var(--blue) 12%,transparent)}
.icon{width:29px;height:29px;border-radius:7px;display:flex;align-items:center;justify-content:center;flex:none;color:#fff;font-size:13px;font-weight:700}
.icon svg{width:17px;height:17px}
.extra{padding:0 16px 12px}
.extra.off{display:none}
.sw{position:relative;width:51px;height:31px;flex:none}
.sw input{position:absolute;inset:0;opacity:0;margin:0;cursor:pointer;z-index:1}
.sw i{position:absolute;inset:0;border-radius:16px;background:var(--track);transition:background .2s}
.sw i::after{content:"";position:absolute;top:2px;left:2px;width:27px;height:27px;border-radius:50%;background:#fff;box-shadow:0 3px 8px rgba(0,0,0,.15),0 1px 1px rgba(0,0,0,.16);transition:transform .2s}
.sw input:checked+i{background:var(--green)}
.sw input:checked+i::after{transform:translateX(20px)}
.sw input:focus-visible+i{outline:2px solid var(--blue);outline-offset:2px}
.slider{display:flex;align-items:center;gap:12px}
.slider .end{font-size:12px;color:var(--label3);min-width:24px}
.slider .end.r{text-align:right}
input[type=range]{-webkit-appearance:none;appearance:none;flex:1;height:28px;background:transparent;margin:0;--p:50%}
input[type=range]::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:linear-gradient(to right,var(--blue) var(--p),var(--track) var(--p))}
input[type=range]::-moz-range-track{height:4px;border-radius:2px;background:linear-gradient(to right,var(--blue) var(--p),var(--track) var(--p))}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:28px;height:28px;border-radius:50%;background:#fff;margin-top:-12px;box-shadow:0 3px 8px rgba(0,0,0,.15),0 0 0 .5px rgba(0,0,0,.08)}
input[type=range]::-moz-range-thumb{width:28px;height:28px;border:0;border-radius:50%;background:#fff;box-shadow:0 3px 8px rgba(0,0,0,.15)}
.seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;background:var(--fill);border-radius:9px;padding:2px;gap:2px}
.seg button{border:0;background:transparent;border-radius:7px;height:30px;font-size:13px;font-weight:500;cursor:pointer}
.seg button[aria-pressed="true"]{background:var(--cell);font-weight:600;box-shadow:0 3px 8px rgba(0,0,0,.12),0 3px 1px rgba(0,0,0,.04)}
.stepper{display:flex;background:var(--fill);border-radius:9px;overflow:hidden;flex:none}
.stepper button{width:44px;height:32px;border:0;background:transparent;font-size:19px;cursor:pointer}
.stepper button+button{border-left:.5px solid var(--sep)}

/* 예산: 제어 센터 밝기 같은 두꺼운 막대 */
.budget{display:flex;flex-direction:column;gap:12px;padding:16px}
.pill{position:relative;width:100%;height:76px;border-radius:22px;background:var(--pill);overflow:hidden;cursor:ew-resize;touch-action:none;user-select:none}
.pill .band{position:absolute;top:0;bottom:0;background:var(--pillfill)}
.pill .h{position:absolute;top:0;bottom:0;width:18px;display:flex;align-items:center;justify-content:center;cursor:ew-resize;outline:none}
.pill .h.lo{left:-1px}
.pill .h.hi{right:-1px}
.pill .h i{width:5px;height:30px;border-radius:3px;background:#C7C7CC}
.pill .h:focus-visible i{background:var(--blue);height:40px}
.pill .pv{position:absolute;top:50%;font-size:15px;font-weight:700;font-variant-numeric:tabular-nums;pointer-events:none;transform:translate(-50%,-50%);white-space:nowrap}
.bsum{display:flex;flex-direction:column;gap:4px;min-width:0}
.bsum>b{font-size:26px;font-weight:700;letter-spacing:-.02em;font-variant-numeric:tabular-nums;line-height:1.15}
.bsum span{font-size:13px;color:var(--label3);line-height:1.45}
.bsum .mini{font-size:13px;color:var(--label);font-weight:700}
.pill .tick{position:absolute;bottom:6px;font-size:11px;font-weight:600;color:rgba(255,255,255,.8);pointer-events:none}
.cta{margin-top:16px;position:sticky;bottom:0;padding-top:10px;background:linear-gradient(to top,var(--bg) 75%,transparent)}
.cta div{height:50px;border-radius:14px;background:var(--blue);color:#fff;font-size:16px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:8px}
.cta.off div{background:var(--pill)}

/* ── 결과 ── */
.main{display:grid;gap:16px;min-width:0}
.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
@media (max-width:760px){.stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
.stat{background:var(--cell);border-radius:12px;padding:14px 16px;min-width:0}
.stat span{font-size:13px;color:var(--label3)}
.stat b{display:block;font-size:30px;font-weight:700;letter-spacing:-.02em;font-variant-numeric:tabular-nums;line-height:1.2}
.stat b.sm{font-size:17px;line-height:1.35;margin-top:6px}
.notice{background:var(--cell);border-radius:12px;padding:14px 16px;color:var(--label2);font-size:15px}
.cols{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:16px;align-items:start}
@media (max-width:1300px){.cols{grid-template-columns:minmax(0,1fr)}}
.col{display:grid;gap:16px;min-width:0}
.card{background:var(--cell);border-radius:12px;overflow:hidden;min-width:0}
.chead{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap;padding:14px 16px 10px}
.chead h2{margin:0;font-size:20px;font-weight:700;letter-spacing:-.01em}
.chead span{font-size:13px;color:var(--label3)}
.list{max-height:520px;overflow-y:auto}
.maprow{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(380px,1fr);gap:16px;align-items:stretch}
.sidecard{display:flex;flex-direction:column;min-height:0;max-height:calc(100vh - 120px)}
.sidecard .tabs{padding:14px 16px 4px}
.seg.big button{min-height:38px;font-size:15px}
.pane{flex:1 1 0;min-height:0;display:flex;flex-direction:column}
#listView .list{flex:1 1 0;min-height:0;max-height:none!important;overflow-y:auto}
.backbar{padding:6px 8px 0}
.backbtn{display:inline-flex;align-items:center;gap:6px;height:40px;padding:0 10px;border:0;background:none;color:var(--blue);font-size:16px;cursor:pointer;border-radius:10px;font-family:inherit}
.backbtn:hover{background:color-mix(in srgb,var(--blue) 10%,transparent)}
.detailscroll{flex:1 1 0;min-height:0;overflow-y:auto}
.listcard{display:flex;flex-direction:column;min-height:0}
.listcard .list{flex:1 1 0;min-height:0;max-height:none}
@media (max-width:1300px){.maprow{grid-template-columns:minmax(0,1fr)}.listcard .list{flex:none;max-height:520px}}
.apt .name{font-weight:600;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.apt .meta{font-size:13px;color:var(--label3)}
.apt .price{font-weight:700;font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}
.badge{display:inline-block;font-size:12px;font-weight:700;border-radius:6px;padding:1px 6px;color:#fff;margin-top:3px}
.badge.b0{background:var(--p0)}.badge.b1{background:var(--p1);color:#1C1C1E}.badge.b2{background:var(--p2)}.badge.b3{background:var(--p3)}
.lost{font-size:13px;color:var(--blue);display:block}
.save{font-size:13px;color:var(--save);font-weight:600}
.more{color:var(--blue);justify-content:center;font-weight:500}

/* 지도 (Leaflet + CARTO 배경 지도) */
/*__LEAFLET_CSS__*/
.map{position:relative;height:clamp(360px,calc(100vh - 330px),640px);background:var(--map)}
@media (max-width:700px){.map{height:420px}}
.map .leaflet-container{background:var(--map);font-family:var(--font)}
/* 한지 느낌: 종이 색 + 잔결 무늬 위에 지도를 반투명하게 얹어, 지도 위에 얇은 한지를 덧댄 것처럼 */
#map.leaflet-container{background-color:var(--paper);background-image:var(--fiber);background-size:180px 180px}
.map .base-tiles{filter:saturate(.45) sepia(.06) brightness(1.06) contrast(.9);opacity:.6}
.map.dark-tiles .base-tiles{filter:invert(1) hue-rotate(180deg) saturate(.7) brightness(1.05) contrast(.9);opacity:.7}
.leaflet-tooltip.apt-tip{font-family:var(--font);font-size:13px;line-height:1.45;border-radius:8px;padding:6px 10px}
.legend{display:flex;flex-wrap:wrap;gap:12px;font-size:12px;color:var(--label3);padding:10px 16px 14px}
.legend i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px;vertical-align:-1px}
.legend i.ring{border:1.5px dashed var(--blue)}

/* 상세 */
.hero{padding:4px 16px 16px}
.hero h3{margin:0;font-size:26px;font-weight:700;letter-spacing:-.02em}
.hero .meta{font-size:13px;color:var(--label3);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kv{display:flex;gap:28px;flex-wrap:wrap;margin-top:14px}
.kv .lbl{font-size:13px;color:var(--label3)}
.kv .big{font-size:32px;font-weight:700;letter-spacing:-.02em;font-variant-numeric:tabular-nums;line-height:1.2}
.kv .prem{font-size:32px;font-weight:700;color:var(--p3);line-height:1.2}
.split{display:flex;height:36px;border-radius:9px;overflow:hidden;font-size:13px;font-weight:600;margin-top:14px}
.split div{display:flex;align-items:center;padding:0 10px;white-space:nowrap;overflow:hidden}
.split .a{background:var(--fill)}
.split .b{background:var(--p2);color:#fff;justify-content:center}
.split{height:30px;position:relative}
.split .b{position:relative;padding:0}
.split .pl{position:absolute;right:10px;top:50%;transform:translateY(-50%);white-space:nowrap;color:var(--label);font-weight:700}
.split .b .pl{color:#fff}
.splitlbl{display:flex;justify-content:space-between;gap:8px;margin-top:6px;font-size:13px;white-space:nowrap}
.splitlbl b{font-weight:700;color:var(--label);font-variant-numeric:tabular-nums;overflow:hidden;text-overflow:ellipsis}
.splitlbl b.pb{color:var(--p2);text-align:right}
.note{font-size:13px;color:var(--label3);margin-top:8px;line-height:1.5}
.sub{font-size:13px;color:var(--label3);padding:0 16px 8px}
.facgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:0;background:var(--cell);border-top:.5px solid var(--sep)}
.facgrid .fc{padding:12px 14px;display:flex;align-items:flex-start;gap:10px;min-width:0;box-shadow:inset -.5px -.5px 0 var(--sep)}
.facgrid .icon{margin-top:2px}
.facgrid .tx{display:flex;flex-direction:column;min-width:0}
.facgrid .k{font-size:12px;color:var(--label3)}
.facgrid b{font-size:17px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.25}
.kv .rng{font-size:26px}
.facgrid .fc.on{background:color-mix(in srgb,var(--blue) 8%,var(--cell))}
.facgrid .fc.off .icon{filter:grayscale(1);opacity:.5}
.facgrid .fc.off b{color:var(--label2)}
.facgrid .cond{font-size:12px;font-weight:600;margin-top:3px;line-height:1.35;word-break:keep-all}
.facgrid .cond.ok{color:var(--save)} .facgrid .cond.near{color:var(--p2)} .facgrid .cond.no{color:var(--p3)}
.facgrid .nm{font-size:12px;color:var(--label2);line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:keep-all}

/* 동네별 · 방법 */
.gbar{display:grid;grid-template-columns:minmax(140px,220px) minmax(0,1fr) 90px;gap:14px;align-items:center}
.gbar .track{height:10px;border-radius:5px;background:var(--track);position:relative;overflow:visible}
.gbar .track i{position:absolute;left:0;top:0;bottom:0;border-radius:5px}
.gbar .track u{position:absolute;top:4px;height:2px;background:var(--label);opacity:.45}
.gbar b{text-align:right;font-variant-numeric:tabular-nums}
@media (max-width:600px){.gbar{grid-template-columns:minmax(0,1fr) 80px}.gbar .track{grid-column:1/-1;grid-row:2}}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1px;background:var(--sep)}
.steps div{background:var(--cell);padding:14px 16px;font-size:14px;color:var(--label2);line-height:1.5}
.steps b{display:block;color:var(--label);font-size:15px;margin-bottom:4px}
.steps em{font-style:normal;color:var(--blue);font-weight:700;font-size:13px}
table{border-collapse:collapse;width:100%;font-size:14px}
th,td{padding:10px 16px;text-align:left;border-top:.5px solid var(--sep)}
th{font-size:12px;color:var(--label3);font-weight:600}
td.r,th.r{text-align:right;font-variant-numeric:tabular-nums}
.tbl{overflow-x:auto}
.empty{padding:20px 16px;color:var(--label3)}
.busy{opacity:.55;transition:opacity .15s}
</style>

<div class="wrap">
  <header class="top">
    <div style="display:flex;flex-direction:column;align-items:flex-start;gap:12px">
      <button type="button" class="sidebtn" id="sideBtn" aria-controls="panel" aria-expanded="true" title="조건 창 닫기">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9.5 4v16"/><path class="pane" d="M5.6 8h1.6M5.6 11h1.6M5.6 14h1.6"/></svg>
        <span id="sideLbl">조건 닫기</span>
      </button>
      <div><h1>동네 프리미엄</h1><p id="eyebrow">대구 아파트 실거래 기반 조건 맞춤 추천</p></div>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:10px;max-width:560px">
      <div class="seg" id="themeSeg" role="group" aria-label="화면 모드" style="width:240px">
        <button type="button" data-theme-set="light">라이트</button><button type="button" data-theme-set="dark">다크</button><button type="button" data-theme-set="system">시스템</button>
      </div>
      <label class="explain-sw" title="작은 설명 글씨를 보이거나 숨겨요"><input type="checkbox" id="explainOn"><span class="knob" aria-hidden="true"></span><span>설명 보기</span></label>
      <p class="lede" style="margin:0;text-align:right">조건을 켜고 끄면 바로 다시 계산해요. 같은 조건인데 왜 어떤 동네가 더 비싼지, 가장 싼 동네와 비교해 보여 줘요.</p>
    </div>
  </header>

  <div class="layout">
    <!-- ───── 조건 ───── -->
    <aside class="panel" aria-label="조건" id="panel">
      <div class="ghead">예산</div>
      <div class="group">
        <div class="budget">
          <div class="bsum"><b id="budgetVal">3억 ~ 5억</b>
            <span class="ex"><b class="mini">왼쪽 끝</b> = 최소, <b class="mini">오른쪽 끝</b> = 최대 · 흰 부분의 양 끝을 좌우로 끌어요</span></div>
          <div class="pill" id="pill">
            <div class="band" id="pBand">
              <span class="h lo" id="hLo" role="slider" tabindex="0" aria-label="최소 예산"><i></i></span>
              <span class="h hi" id="hHi" role="slider" tabindex="0" aria-label="최대 예산"><i></i></span>
            </div>
            <span class="tick" style="left:12px">0억</span><span class="tick" style="right:12px">10억+</span>
            <span class="pv" id="pvLo"></span><span class="pv" id="pvHi"></span>
          </div>
          <span style="font-size:12px;color:var(--label3)">가운데를 누르면 가까운 쪽 끝이 따라와요 · 방향키로 0.1억씩 · 오른쪽 끝까지 올리면 상한 없음</span>
        </div>
      </div>
      <p class="foot">그 평형의 최근 1년 실거래 중앙값과 비교해요. 1년 안에 거래가 없으면 2년, 3년으로 넓혀요. 그 기간 거래가 3건 미만이면 범위 대신 한 값으로 보여 줘요.</p>

      <div class="ghead">평형</div>
      <div class="group">
        <button class="row" id="bandRow" type="button" aria-expanded="false"><span class="t">전용면적</span><span class="v" id="bandVal"></span>
          <svg class="chev" id="bandChev" viewBox="0 0 8 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transition:transform .2s"><path d="M1 1l6 6-6 6"/></svg></button>
        <div id="bandList" hidden></div>
      </div>
      <p class="foot">59㎡형과 84㎡형이 전체 거래의 71%예요. 거래가 적은 평형은 프리미엄이 '참고'로 나올 수 있어요.</p>

      <div class="ghead">가까워야 하는 시설</div>
      <div class="group" id="facGroup"></div>
      <p class="foot">가장 가까운 곳까지 실제로 걸어가는 길로 잰 시간이에요. 버스는 대부분 5분 안이라 뺐어요.</p>

      <div class="ghead">많을수록 좋은 시설</div>
      <div class="group" id="denseGroup"></div>
      <p class="foot">걸어서 10분 안에 있는 개수예요.</p>

      <div class="ghead">멀수록 좋은 시설</div>
      <div class="group" id="avoidGroup"></div>

      <div class="ghead">아깝게 놓친 매물</div>
      <div class="group">
        <div class="row"><span class="t">함께 보기</span><label class="sw"><input type="checkbox" id="nearOn" checked aria-label="아깝게 놓친 매물 함께 보기"><i></i></label></div>
        <div class="row" id="allow2Row"><span class="t">조건 두 개까지 넓히기</span><label class="sw"><input type="checkbox" id="allow2" aria-label="조건 두 개까지"><i></i></label></div>
      </div>
      <p class="foot">도보 +2분, 개수 80% 이상, 유흥주점 +1개, 예산 +5%까지 조금 못 미친 매물이에요.</p>

      <div class="cta" id="cta"><div id="ctaText">계산 중…</div></div>
    </aside>

    <!-- ───── 결과 ───── -->
    <main class="main" id="main" aria-live="polite">
      <div class="stats" id="stats" hidden></div>
      <div id="notice" hidden></div>
      <div class="maprow">
        <section class="card mapcard">
          <div class="chead"><h2>지도</h2><span>점에 마우스를 올리면 정보, 누르면 그 동네로 확대</span></div>
          <div class="map" id="map" role="region" aria-label="대구 아파트 지도"></div>
          <div class="legend" id="legend"></div>
        </section>
        <section class="card sidecard" id="sidecard" aria-label="매물 정보">
          <div class="tabs"><div class="seg big" id="viewSeg" role="tablist" aria-label="매물 종류"></div></div>
          <div class="pane" id="listView">
            <div class="chead"><h2 id="listTitle">조건 충족 매물</h2><span id="listSub"></span></div>
            <div id="sortWrap" style="padding:0 16px 10px"><div class="seg" id="sortSeg"></div></div>
            <div class="list" id="aptList"></div>
            <div class="list" id="missList" hidden></div>
          </div>
          <div class="pane" id="detailView" hidden>
            <div class="backbar"><button type="button" class="backbtn" id="backBtn"><svg viewBox="0 0 10 16" width="9" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 2L2 8l6 6"/></svg><span id="backLbl">목록</span></button></div>
            <div class="detailscroll"><section id="detail"></section></div>
          </div>
        </section>
      </div>
      <section class="card" id="groupCard">
        <div class="chead"><h2>동네별 프리미엄</h2><span>같은 구 안에서 서로 2km 안에 모인 아파트끼리 한 동네 · 가는 선은 80% 범위</span></div>
        <div id="groupBars" style="padding:4px 16px 16px;display:grid;gap:4px;max-height:560px;overflow-y:auto"></div>
      </section>
      <section class="card">
        <div class="chead"><h2>이 서비스는 어떻게 계산하나요?</h2></div>
        <div class="steps">
          <div><em>1 · 규칙</em><b>조건 필터</b>예산·평형·시설 조건을 모두 만족하는 아파트만 남겨요. 하나만 조금 못 미치면 놓친 매물로 따로 보여 줘요.</div>
          <div><em>2 · 계층 군집</em><b>이웃 묶기</b>같은 구 안에서 서로 2km 안에 모인 아파트끼리 한 동네로 묶어요.</div>
          <div><em>3 · 모델 A + 회귀</em><b>동네 프리미엄</b>층·연식·거래 시기 차이를 걷어내고 동네끼리 비교해요. 가장 싼 동네가 0%예요.</div>
          <div><em>4 · 모델 B</em><b>어디서 왔을까</b>시설 차이로 설명되는 몫과 설명 안 되는 몫을 참고로 나눠요.</div>
          <div><em>5 · 모델 B</em><b>예상가 대비</b>주변 시설 수준으로 예상한 가격보다 실제로 싼지 비싼지예요.</div>
        </div>
        <div class="tbl"><table id="modelTbl"></table></div>
        <p class="note" style="padding:0 16px 16px" id="foot"></p>
      </section>
    </main>
  </div>
</div>

<script>/*__LEAFLET_JS__*/</script>
<script>
const APTS=/*__APTS__*/null, TRADES=/*__TRADES__*/null, META=/*__META__*/null;

/* ───────── 기본 정보 ───────── */
const FACS=META.facs, DENSE=META.dense, NUIS="유흥주점";
const LABEL={도시철도역:"지하철역",초등학교:"초등학교",중학교:"중학교",고등학교:"고등학교",공원:"공원",종합병원:"종합병원",대형마트:"대형마트",편의점:"편의점",의원:"의원",입시학원:"입시학원",음식점:"음식점",유흥주점:"유흥주점"};
const SCHOOL='<path d="M3 10l9-5 9 5-9 5-9-5z"/><path d="M7 12v5c0 1 2.5 2.5 5 2.5s5-1.5 5-2.5v-5"/><path d="M21 10v5"/>';
const ICON={
  도시철도역:["#007AFF",'<rect x="6" y="3" width="12" height="14" rx="3"/><path d="M6 11h12M9 14.5h.01M15 14.5h.01M8 21l2-4M16 21l-2-4"/>'],
  초등학교:["#34C759",SCHOOL], 중학교:["#30B0C7",SCHOOL], 고등학교:["#5856D6",SCHOOL],
  공원:["#28A745",'<path d="M12 21v-6"/><path d="M12 3l5 7h-3l4 5H6l4-5H7z"/>'],
  종합병원:["#FF3B30",'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M12 8v8M8 12h8"/>'],
  대형마트:["#FF9500",'<path d="M3 4h2l2.2 10.5a1 1 0 001 .8h8.6a1 1 0 001-.8L20 8H6.2"/><circle cx="9" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/>'],
  편의점:["#5AC8FA",'<path d="M4 9l1.5-5h13L20 9"/><path d="M4 9a2.7 2.7 0 005.3 0 2.7 2.7 0 005.4 0 2.7 2.7 0 005.3 0"/><path d="M5.5 12v8h13v-8M10 20v-4.5h4V20"/>'],
  의원:["#FF2D55",'<path d="M7 4v5a5 5 0 0010 0V4"/><path d="M12 14v2a4 4 0 008 0v-2"/><circle cx="20" cy="12" r="1.6"/>'],
  입시학원:["#AF52DE",'<path d="M12 6c-2-1.5-5-2-8-1.5V19c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V4.5c-3-.5-6 0-8 1.5z"/><path d="M12 6v14.5"/>'],
  음식점:["#FF9F0A",'<path d="M7 3v8M5 3v5a2 2 0 004 0V3M7 11v10"/><path d="M17 21V3c-2 1.5-3 4-3 7h3"/>'],
  유흥주점:["#8E8E93",'<path d="M7 3h10l-1 6a4 4 0 01-8 0L7 3z"/><path d="M12 13v7M8.5 20.5h7"/>'],
  하수처리장:["#8E8E93",'<path d="M12 3.5c3 4 5.5 7 5.5 10.2a5.5 5.5 0 01-11 0C6.5 10.5 9 7.5 12 3.5z"/>']};
const FAC_ORDER=["도시철도역","초등학교","중학교","고등학교","공원","종합병원","대형마트"].filter(f=>FACS.includes(f));
const BANDS=[{lo:0,hi:44,t:"44㎡ 이하",s:"~44㎡"},{lo:44,hi:55,t:"49㎡형",s:"44~55㎡"},{lo:55,hi:62,t:"59㎡형",s:"55~62㎡"},{lo:62,hi:73,t:"66~72㎡형",s:"62~73㎡"},
  {lo:73,hi:79,t:"74㎡형",s:"73~79㎡"},{lo:79,hi:90,t:"84㎡형",s:"79~90㎡"},{lo:90,hi:108,t:"99~101㎡형",s:"90~108㎡"},{lo:108,hi:120,t:"114㎡형",s:"108~120㎡"},
  {lo:120,hi:131,t:"125㎡형",s:"120~131㎡"},{lo:131,hi:140,t:"134㎡형",s:"131~140㎡"},{lo:140,hi:1e9,t:"140㎡ 초과",s:"140㎡~"}];
const TIERS=[{lim:5,name:"기본가 수준",k:0},{lim:15,name:"낮음",k:1},{lim:30,name:"보통",k:2},{lim:1e9,name:"높음",k:3}];
const NEIGHBOR_KM=2, MIN_GROUPS=3, MIN_GROUP_TRADES=10, BOOT=60, MAX_T_PER_APT=30;
const B_MIN=0, B_MAX=10;   // 최대를 끝까지 올리면 상한 없음(10억 이상 포함)
const N=APTS.name.length, NT=TRADES.c.length;
const T={d:TRADES.d||null,c:TRADES.c,m:TRADES.m,lp:TRADES.lp,pA:TRADES.pA,pB:TRADES.pB,area:TRADES.area,fl:TRADES.fl,age:TRADES.age,mx:TRADES.mx,rf:TRADES.rf,pBf:TRADES.pBf};
const M0=META.idx.m0, IDX=META.idx.v; let REFM=0; for(let i=0;i<NT;i++) if(T.m[i]>REFM) REFM=T.m[i];
const iv=m=>IDX[m-M0]||0;
const cssv=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();

function featVal(i,key){
  if(key.startsWith("t_")){const F=APTS.fac[key.slice(2)]; return F.b[i]===99?META.no_fac_min:F.t[i];}
  if(key.startsWith("n_")) return APTS.dense[key.slice(2)][i];
  const s=APTS.sewer[i]; return s==null?META.no_sewer_m:s;
}
const COLB=META.colB, KEYCOL={}; COLB.forEach((c,j)=>{const k=META.colKey[c]; if(k) KEYCOL[k]=j;});
const PHYS={area:COLB.indexOf("area"),floor:COLB.indexOf("floor"),rel_floor:COLB.indexOf("rel_floor"),max_floor:COLB.indexOf("max_floor"),age:COLB.indexOf("age"),m:COLB.indexOf("m")};
const FEATKEYS=Object.keys(KEYCOL);
function rowB(t){const x=new Float64Array(COLB.length), c=T.c[t];
  x[PHYS.area]=T.area[t]; x[PHYS.floor]=T.fl[t]; x[PHYS.rel_floor]=T.rf[t]/1e4; x[PHYS.max_floor]=T.mx[t]; x[PHYS.age]=T.age[t]; x[PHYS.m]=T.m[t];
  for(const k of FEATKEYS) x[KEYCOL[k]]=featVal(c,k); return x;}
const TR=META.treesB;
function predict(x){let s=0; for(let k=0;k<TR.root.length;k++){const no=TR.noff[k]; let n=TR.root[k]; while(n>=0){const j=no+n; n=x[TR.nf[j]]<=TR.th[j]?TR.lc[j]:TR.rc[j];} s+=TR.lv[TR.loff[k]+~n];} return s;}

function won(v){v=Math.round(v/100)*100; const sg=v<0?"−":""; v=Math.abs(v); const e=Math.floor(v/10000), r=v%10000;
  if(e&&r) return `${sg}${e}억 ${r.toLocaleString()}만`; if(e) return `${sg}${e}억`; return `${sg}${r.toLocaleString()}만`;}
const eok=v=>v>=10?"10억+":(Math.round(v*10)/10).toString().replace(/\.0$/,"")+"억";
const r5=v=>Math.round(v/5)*5;
const tierOf=p=>TIERS.find(t=>p<t.lim);
const median=a=>{if(!a.length) return NaN; const s=[...a].sort((x,y)=>x-y), h=s.length>>1; return s.length%2?s[h]:(s[h-1]+s[h])/2;};
const quant=(a,q)=>{const s=[...a].sort((x,y)=>x-y), i=(s.length-1)*q, lo=Math.floor(i); return s[lo]+(s[Math.min(lo+1,s.length-1)]-s[lo])*(i-lo);};
const mean=a=>a.reduce((s,v)=>s+v,0)/a.length;
const qtile=(a,q)=>{const s=[...a].sort((x,y)=>x-y); const p=(s.length-1)*q, lo=Math.floor(p), hi=Math.ceil(p); return s[lo]+(s[hi]-s[lo])*(p-lo);};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const dongOf=i=>(APTS.dong&&APTS.dong[i])||"";

/* ───────── 평형별 거래 · 시세 ───────── */
const tBand=new Int8Array(NT); for(let t=0;t<NT;t++){const a=T.area[t]; tBand[t]=BANDS.findIndex(b=>a>b.lo&&a<=b.hi);}
const LISTS=BANDS.map(()=>Array.from({length:N},()=>[])); for(let t=0;t<NT;t++) if(tBand[t]>=0) LISTS[tBand[t]][T.c[t]].push(t);
const BAND_N=BANDS.map((_,b)=>{let n=0; for(let t=0;t<NT;t++) if(tBand[t]===b) n++; return n;});
const PRICE_CACHE={};
function lastDate(t){const m=T.m[t], y=2023+Math.floor(m/12), mo=m%12+1; return `${y}.${String(mo).padStart(2,"0")}`+(T.d?`.${String(T.d[t]).padStart(2,"0")}`:"");}
function prices(band){
  if(PRICE_CACHE[band]) return PRICE_CACHE[band];
  const out=new Array(N).fill(null);
  for(let c=0;c<N;c++){
    const all=LISTS[band][c]; if(!all.length) continue; let win=null,w=null;
    for(const ww of [12,24,null]){win=ww==null?all:all.filter(t=>T.m[t]>REFM-ww); w=ww; if(win.length) break;}
    const adj=win.map(t=>T.lp[t]/1e4-iv(T.m[t])+iv(REFM)), area=median(win.map(t=>T.area[t]));
    let sw=0,sr=0; for(const t of all){const w2=Math.pow(.5,(REFM-T.m[t])/6); sw+=w2; sr+=w2*(T.lp[t]-T.pB[t])/1e4;}
    const rp=v=>Math.round(Math.exp(v)*area/100)*100, price=rp(median(adj)), few=adj.length<3;   // 시세 범위: 시점 보정한 거래의 가운데 50% (거래 3건 미만이면 한 값)
    let lt=all[0]; for(const t of all) if(T.m[t]>T.m[lt]||(T.m[t]===T.m[lt]&&T.d&&T.d[t]>T.d[lt])) lt=t;
    out[c]={last:lastDate(lt), price, lo:few?price:Math.min(price,rp(quant(adj,.25))), hi:few?price:Math.max(price,rp(quant(adj,.75))), nw:adj.length, area, win:w, n:all.length, value:Math.expm1(sr/(sw+1))*100};
  }
  return PRICE_CACHE[band]=out;
}

/* ───────── 조건 ───────── */
const S={lo:3,hi:5,band:5,fac:{도시철도역:10,초등학교:10},facOff:{},dense:{입시학원:10},denseOff:{편의점:10,의원:10,음식점:50},nuis:null,nuisOff:2,sewer:null,sewerOff:1,near:true,allow2:false};
function conds(){const L=[{kind:"budget"}];
  for(const f of FAC_ORDER) if(S.fac[f]!=null) L.push({kind:"fac",f,key:"t_"+f,lim:S.fac[f]});
  for(const f of DENSE) if(S.dense[f]!=null) L.push({kind:"dense",f,key:"n_"+f,lim:S.dense[f]});
  if(S.nuis!=null) L.push({kind:"nuis",f:NUIS,key:"n_"+NUIS,lim:S.nuis});
  if(S.sewer!=null) L.push({kind:"sewer",key:"sewer_m",lim:S.sewer});
  return L;}
function check(c,cd,P){
  if(cd.kind==="budget"){const p=P[c].price; if(p<S.lo*1e4) return [2]; if(S.hi>=B_MAX||p<=S.hi*1e4) return [0]; return p<=S.hi*1e4*1.05?[1,p]:[2];}
  if(cd.kind==="fac"){const F=APTS.fac[cd.f]; const t=F.b[c]===99?Infinity:F.t[c]; return t<=cd.lim?[0,t]:t<=cd.lim+2?[1,t]:[2,t];}
  if(cd.kind==="dense"){const n=APTS.dense[cd.f][c]; return n>=cd.lim?[0,n]:(cd.lim>0&&n>=Math.ceil(cd.lim*.8))?[1,n]:[2,n];}
  if(cd.kind==="nuis"){const n=APTS.dense[NUIS][c]; return n<=cd.lim?[0,n]:n<=cd.lim+1?[1,n]:[2,n];}
  const s=APTS.sewer[c]; const d=s==null?Infinity:s; return d>=cd.lim*1000?[0,d]:[2,d];}
function missText(cd,v){
  if(cd.kind==="budget") return `예산 ${won(v)} (상한 +${((v/(S.hi*1e4)-1)*100).toFixed(1)}%)`;
  if(cd.kind==="fac") return `${LABEL[cd.f]} 걸어서 ${v.toFixed(1)}분 (조건 ${cd.lim}분)`;
  if(cd.kind==="dense") return `10분 안 ${LABEL[cd.f]} ${v}개 (조건 ${cd.lim}개 이상)`;
  return `10분 안 유흥주점 ${v}개 (조건 ${cd.lim}개 이하)`;}

/* ───────── 2km 묶기 · 고정효과 회귀 ───────── */
function hav(a,b){const R=6371,l1=APTS.lat[a]*Math.PI/180,l2=APTS.lat[b]*Math.PI/180,dl=l2-l1,dn=(APTS.lon[b]-APTS.lon[a])*Math.PI/180;
  const h=Math.sin(dl/2)**2+Math.cos(l1)*Math.cos(l2)*Math.sin(dn/2)**2; return 2*R*Math.asin(Math.sqrt(h));}
function cluster(ids){
  const byGu={}; ids.forEach(c=>(byGu[APTS.gu[c]]??=[]).push(c)); const groups=[];
  for(const [gu,list] of Object.entries(byGu)){
    const n=list.length, D=Array.from({length:n},()=>new Float64Array(n));
    for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){const d=hav(list[i],list[j]); D[i][j]=D[j][i]=d;}
    const mem=list.map(c=>[c]), alive=new Array(n).fill(true);
    while(true){let best=Infinity,bi=-1,bj=-1;
      for(let i=0;i<n;i++) if(alive[i]) for(let j=i+1;j<n;j++) if(alive[j]&&D[i][j]<best){best=D[i][j];bi=i;bj=j;}
      if(bi<0||best>NEIGHBOR_KM) break; mem[bi]=mem[bi].concat(mem[bj]); alive[bj]=false;
      for(let k=0;k<n;k++) if(alive[k]&&k!==bi){const d=Math.max(D[bi][k],D[bj][k]); D[bi][k]=D[k][bi]=d;}}
    for(let i=0;i<n;i++) if(alive[i]) groups.push({gu,members:mem[i]});
  }
  const used={};
  for(const g of groups){const cnt={}; g.members.forEach(c=>{const d=dongOf(c); if(d) cnt[d]=(cnt[d]||0)+1;});
    const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0]; const base=`${g.gu} ${top?top[0]:""}`.trim();
    used[base]=(used[base]||0)+1; g.name=used[base]===1?base:`${base} (${used[base]})`;}
  return groups;
}
function solve(A,b,p){
  for(let i=0;i<p;i++) A[i*p+i]+=1e-8;
  for(let col=0;col<p;col++){let piv=col; for(let r=col+1;r<p;r++) if(Math.abs(A[r*p+col])>Math.abs(A[piv*p+col])) piv=r;
    if(piv!==col){for(let k=0;k<p;k++){const t=A[col*p+k];A[col*p+k]=A[piv*p+k];A[piv*p+k]=t;} const t=b[col];b[col]=b[piv];b[piv]=t;}
    const d=A[col*p+col]; if(Math.abs(d)<1e-14) continue;
    for(let r=col+1;r<p;r++){const f=A[r*p+col]/d; if(!f) continue; for(let k=col;k<p;k++) A[r*p+k]-=f*A[col*p+k]; b[r]-=f*b[col];}}
  const x=new Float64Array(p); for(let i=p-1;i>=0;i--){let s=b[i]; for(let k=i+1;k<p;k++) s-=A[i*p+k]*x[k]; const d=A[i*p+i]; x[i]=Math.abs(d)<1e-14?0:s/d;} return x;}
function fe(cells,field,ref){
  const gs=[...new Set(cells.map(c=>c.g))].filter(g=>g!==ref), qs=[...new Set(cells.map(c=>c.q))];
  const gi=new Map(gs.map((g,i)=>[g,i])), qi=new Map(qs.map((q,i)=>[q,gs.length+i]));
  const p=gs.length+qs.length, A=new Float64Array(p*p), b=new Float64Array(p);
  for(const c of cells){const w=c.n/(c.n+1), y=c[field], a=gi.has(c.g)?gi.get(c.g):-1, q=qi.get(c.q);
    A[q*p+q]+=w; b[q]+=w*y; if(a>=0){A[a*p+a]+=w; A[a*p+q]+=w; A[q*p+a]+=w; b[a]+=w*y;}}
  const x=solve(A,b,p), out=new Map([[ref,0]]); gs.forEach((g,i)=>out.set(g,x[i])); return out;}

/* ───────── 계산 ───────── */
let R=null;
function compute(){
  const P=prices(S.band), CD=conds(), cand=[], near=[];
  for(let c=0;c<N;c++){
    if(!P[c]) continue; let hard=false; const miss=[];
    for(const cd of CD){const [r,v]=check(c,cd,P); if(r===2){hard=true;break;} if(r===1) miss.push({cd,v});}
    if(hard) continue; if(!miss.length) cand.push(c); else if(miss.length<=(S.allow2?2:1)) near.push({c,miss});
  }
  const res={P,cand,near,CD,groups:[],gOf:new Map(),premium:false,fit:new Map()};
  const sel=CD.filter(d=>d.kind!=="budget");
  if(sel.length&&cand.length){
    const parts=sel.map(cd=>{const good=c=>cd.kind==="fac"?-featVal(c,cd.key):cd.kind==="nuis"?-APTS.dense[NUIS][c]:featVal(c,cd.key);
      const vals=cand.map(c=>[c,good(c)]).sort((a,b)=>a[1]-b[1]); const m=new Map(); let i=0;
      while(i<vals.length){let j=i; while(j+1<vals.length&&vals[j+1][1]===vals[i][1]) j++; const rk=(i+j)/2+1; for(let k=i;k<=j;k++) m.set(vals[k][0],rk/vals.length); i=j+1;}
      return m;});
    cand.forEach(c=>res.fit.set(c,Math.round(mean(parts.map(m=>m.get(c)))*100)));
  }
  if(cand.length){
    const groups=cluster(cand); groups.forEach((g,k)=>{g.id=k; g.members.forEach(c=>res.gOf.set(c,k));});
    const cellMap=new Map();
    for(const c of cand) for(const t of LISTS[S.band][c]){const q=Math.floor(T.m[t]/3), key=c*100+q;
      let e=cellMap.get(key); if(!e){e={c,g:res.gOf.get(c),q,rA:0,rB:0,n:0}; cellMap.set(key,e);} e.rA+=(T.lp[t]-T.pA[t])/1e4; e.rB+=(T.lp[t]-T.pB[t])/1e4; e.n++;}
    const cells=[...cellMap.values()]; cells.forEach(e=>{e.rA/=e.n; e.rB/=e.n;});
    groups.forEach(g=>{g.trades=g.members.reduce((s,c)=>s+LISTS[S.band][c].length,0); g.n=g.members.length;});
    res.groups=groups;
    if(groups.length>=MIN_GROUPS){
      res.premium=true;
      const ref=groups.reduce((a,b)=>b.trades>a.trades?b:a).id, bA=fe(cells,"rA",ref), bB=fe(cells,"rB",ref);
      const pool=groups.filter(g=>g.trades>=MIN_GROUP_TRADES), pl=pool.length?pool:groups;
      const base=pl.reduce((a,b)=>bA.get(b.id)<bA.get(a.id)?b:a).id; res.base=base;
      const keys=sel.map(d=>d.key), bv={}; keys.forEach(k=>bv[k]=mean(groups[base].members.map(c=>featVal(c,k))));
      const d2c=new Map();
      if(keys.length) for(const c of cand){const ts=LISTS[S.band][c].slice().sort((a,b)=>T.m[b]-T.m[a]).slice(0,MAX_T_PER_APT); let s=0;
        for(const t of ts){const x=rowB(t); keys.forEach(k=>x[KEYCOL[k]]=bv[k]); s+=T.pBf[t]/1e6-predict(x);} d2c.set(c,s/ts.length);}
      const d2g=groups.map(g=>keys.length?mean(g.members.map(c=>d2c.get(c))):0);
      const byC=new Map(); cells.forEach(e=>{(byC.get(e.c)||byC.set(e.c,[]).get(e.c)).push(e);});
      const ids=[...byC.keys()], boots=groups.map(()=>[]); let seed=42; const rnd=()=>(seed=(seed*1664525+1013904223)>>>0)/4294967296;
      for(let b=0;b<BOOT;b++){const cb=[]; for(let i=0;i<ids.length;i++) cb.push(...byC.get(ids[Math.floor(rnd()*ids.length)]));
        const gset=new Set(cb.map(e=>e.g)); if(!gset.has(ref)||!gset.has(base)) continue;
        const e=fe(cb,"rA",ref), b0=e.get(base); groups.forEach(g=>{if(e.has(g.id)) boots[g.id].push(e.get(g.id)-b0);});}
      for(const g of groups){
        g.P=bA.get(g.id)-bA.get(base); g.c3=bB.get(g.id)-bB.get(base); g.c2=d2g[g.id]-d2g[base]; g.c1=g.P-g.c2-g.c3;
        g.pct=Math.max(0,Math.expm1(g.P)*100); const sh=g.P>0?g.pct/g.P:0; g.p1=g.c1*sh; g.p2=g.c2*sh; g.p3=g.c3*sh;
        const bs=boots[g.id]; g.lo=bs.length>10?Math.max(0,Math.expm1(qtile(bs,.1))*100):null; g.hi=bs.length>10?Math.max(0,Math.expm1(qtile(bs,.9))*100):null;
        g.ref=g.id!==base&&(g.trades<MIN_GROUP_TRADES||(bs.length>10?qtile(bs,.1):-1)<=0||g.n===1);
      }
    }
  }
  const med=median(cand.map(c=>P[c].price)); res.candMed=med;
  for(const it of near){it.price=P[it.c].price; it.diff=med-it.price;
    const ks=it.miss.filter(m=>m.cd.kind!=="budget");
    if(ks.length){const ts=LISTS[S.band][it.c].slice().sort((a,b)=>T.m[b]-T.m[a]).slice(0,MAX_T_PER_APT); let s=0;
      for(const t of ts){const x=rowB(t); ks.forEach(m=>x[KEYCOL[m.cd.key]]=m.cd.lim); s+=predict(x)-T.pBf[t]/1e6;}
      it.lossPct=Math.expm1(s/ts.length); it.loss=it.price*it.lossPct;} else it.loss=null;}
  near.sort((a,b)=>a.price-b.price);
  R=res;
}
function drivers(g){
  if(!R.premium||g.id===R.base) return [];
  const bm=R.groups[R.base].members, gm=g.members, ts=[]; gm.forEach(c=>LISTS[S.band][c].slice(-12).forEach(t=>ts.push(t)));
  const sample=ts.slice(0,200), X=sample.map(rowB), p0=sample.map(t=>T.pBf[t]/1e6), out=[];
  for(const k of FEATKEYS){const bv=mean(bm.map(c=>featVal(c,k))), ov=mean(gm.map(c=>featVal(c,k))); if(Math.abs(bv-ov)<1e-6) continue;
    let s=0; X.forEach((x,i)=>{const z=Float64Array.from(x); z[KEYCOL[k]]=bv; s+=p0[i]-predict(z);}); out.push({k,eff:s/X.length,ov,bv});}
  return out.sort((a,b)=>Math.abs(b.eff)-Math.abs(a.eff)).slice(0,3);
}
const featName=k=>k.startsWith("t_")?`${LABEL[k.slice(2)]}까지 도보`:k.startsWith("n_")?`걸어서 10분 안 ${LABEL[k.slice(2)]}`:"하수처리장까지 거리";
const featText=(k,v)=>k.startsWith("t_")?(v>=META.no_fac_min-.01?"20분 넘음":`${v.toFixed(0)}분`):k.startsWith("n_")?`${Math.round(v)}개`:(v>=META.no_sewer_m-1?"3km 넘음":`${(v/1000).toFixed(1)}km`);

/* ───────── 조건 패널 ───────── */
const chev=`<svg class="chev" viewBox="0 0 8 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 1l6 6-6 6"/></svg>`;
const icon=f=>`<span class="icon" style="background:${ICON[f][0]}" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICON[f][1]}</svg></span>`;
const sw=(id,on,label)=>`<label class="sw"><input type="checkbox" id="${id}" ${on?"checked":""} aria-label="${label}"><i></i></label>`;
function setFill(r){r.style.setProperty("--p",((r.value-r.min)/(r.max-r.min)*100)+"%");}
function buildCond(){
  document.getElementById("facGroup").innerHTML=FAC_ORDER.map(f=>{const on=S.fac[f]!=null, v=on?S.fac[f]:(S.facOff[f]||10);
    return `<div class="row ic">${icon(f)}<span class="t">${LABEL[f]}</span><span class="v" id="fv_${f}">${on?v+"분 이내":""}</span>${sw("fc_"+f,on,LABEL[f])}</div>
      <div class="extra ${on?"":"off"}" id="fx_${f}"><div class="seg" role="group" aria-label="${LABEL[f]} 도보 시간">${[5,10,15,20].map(m=>`<button type="button" data-f="${f}" data-m="${m}" aria-pressed="${m===v}">${m}분</button>`).join("")}</div></div>`;}).join("");
  document.getElementById("denseGroup").innerHTML=DENSE.map(f=>{const on=S.dense[f]!=null, v=on?S.dense[f]:(S.denseOff[f]||10), mx=f==="음식점"?200:80;
    return `<div class="row ic">${icon(f)}<span class="t">${LABEL[f]}</span><span class="v" id="dv_${f}">${on?v+"개 이상":""}</span>${sw("dc_"+f,on,LABEL[f])}</div>
      <div class="extra ${on?"":"off"}" id="dx_${f}"><div class="slider"><span class="end">0</span><input type="range" id="dr_${f}" min="0" max="${mx}" step="1" value="${v}" aria-label="${LABEL[f]} 최소 개수"><span class="end r">${mx}</span></div></div>`;}).join("");
  document.getElementById("avoidGroup").innerHTML=`
    <div class="row ic">${icon(NUIS)}<span class="t">유흥주점 <span style="font-size:13px;color:var(--label3)">10분 안</span></span><span class="v" id="nv">${S.nuis!=null?S.nuis+"개 이하":""}</span>${sw("nc",S.nuis!=null,"유흥주점")}</div>
    <div class="extra ${S.nuis!=null?"":"off"}" id="nx"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px"><span style="font-size:14px;color:var(--label3)">최대 개수</span>
      <div class="stepper"><button type="button" id="nMinus" aria-label="하나 줄이기">−</button><button type="button" id="nPlus" aria-label="하나 늘리기">+</button></div></div></div>
    <div class="row ic">${icon("하수처리장")}<span class="t">하수처리장 <span style="font-size:13px;color:var(--label3)">직선거리</span></span><span class="v" id="sv">${S.sewer!=null?S.sewer+"km 이상":""}</span>${sw("sc",S.sewer!=null,"하수처리장")}</div>
    <div class="extra ${S.sewer!=null?"":"off"}" id="sx"><div class="seg" role="group" aria-label="하수처리장 최소 거리">${[1,2,3].map(k=>`<button type="button" data-sw="${k}" aria-pressed="${k===S.sewerOff}">${k}km 이상</button>`).join("")}</div></div>`;
  buildBand();
  document.querySelectorAll("#panel input[type=range]").forEach(setFill);
}
function buildBand(){
  document.getElementById("bandVal").textContent=`${BANDS[S.band].t} (${BANDS[S.band].s})`;
  document.getElementById("bandList").innerHTML=BANDS.map((b,i)=>`<button class="row" type="button" data-band="${i}" aria-current="${i===S.band}"><span class="t">${b.t}<span style="display:block;font-size:13px;color:var(--label3)">${b.s} · 거래 ${BAND_N[i].toLocaleString()}건</span></span>${i===S.band?`<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="var(--blue)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8.5l4 4 8-9"/></svg>`:""}</button>`).join("");
}

/* 예산: 막대 하나 — 흰 부분 아래 끝 = 최소, 위 끝 = 최대 */
const xOf=v=>(v-B_MIN)/(B_MAX-B_MIN)*100;   // 왼쪽에서부터 %
function updateBudget(){
  const L=xOf(S.lo), Rr=xOf(S.hi), band=document.getElementById("pBand");
  band.style.left=L+"%"; band.style.right=(100-Rr)+"%";
  const hv=document.getElementById("pvHi"), lv=document.getElementById("pvLo"), wide=document.getElementById("pill").clientWidth*(Rr-L)/100;
  hv.textContent=eok(S.hi); lv.textContent=eok(S.lo);
  if(wide>=130){lv.style.left=`calc(${L}% + 40px)`; hv.style.left=`calc(${Rr}% - 40px)`; hv.style.color=lv.style.color="#1C1C1E";}
  hv.hidden=lv.hidden=wide<130;   // 흰 부분이 좁으면 막대 안 숫자는 숨기고 위의 큰 숫자로만 보여 줌
  [["hHi",S.hi],["hLo",S.lo]].forEach(([id,v])=>{const h=document.getElementById(id); h.setAttribute("aria-valuemin",B_MIN); h.setAttribute("aria-valuemax",B_MAX); h.setAttribute("aria-valuenow",v); h.setAttribute("aria-valuetext",eok(v));});
  document.getElementById("budgetVal").textContent=`${eok(S.lo)} ~ ${eok(S.hi)}`;
}
function wirePill(){
  const el=document.getElementById("pill"); let grab=null;
  const vOf=x=>{const r=el.getBoundingClientRect(); return Math.round(Math.max(B_MIN,Math.min(B_MAX,B_MIN+(x-r.left)/r.width*(B_MAX-B_MIN)))*10)/10;};
  const apply=v=>{if(grab==="hi") S.hi=Math.max(v,S.lo); else S.lo=Math.min(v,S.hi); updateBudget(); schedule();};
  el.addEventListener("pointerdown",e=>{const v=vOf(e.clientX); const h=e.target.closest(".h");
    grab=h?(h.id==="hHi"?"hi":"lo"):(v>=S.hi?"hi":v<=S.lo?"lo":(S.hi-v<v-S.lo?"hi":"lo"));
    el.setPointerCapture(e.pointerId); (grab==="hi"?document.getElementById("hHi"):document.getElementById("hLo")).focus({preventScroll:true}); apply(v);});
  el.addEventListener("pointermove",e=>{if(grab&&el.hasPointerCapture(e.pointerId)) apply(vOf(e.clientX));});
  el.addEventListener("pointerup",()=>{grab=null;});
  [["hHi","hi"],["hLo","lo"]].forEach(([id,w])=>document.getElementById(id).addEventListener("keydown",e=>{
    const d={ArrowUp:.1,ArrowRight:.1,ArrowDown:-.1,ArrowLeft:-.1,PageUp:1,PageDown:-1}[e.key]; if(d==null) return; e.preventDefault();
    if(w==="hi") S.hi=Math.round(Math.max(S.lo,Math.min(B_MAX,S.hi+d))*10)/10; else S.lo=Math.round(Math.max(B_MIN,Math.min(S.hi,S.lo+d))*10)/10;
    updateBudget(); schedule();}));
  addEventListener("resize",updateBudget);
}
function wireCond(){
  const pn=document.getElementById("panel");
  wirePill();
  pn.addEventListener("input",e=>{const t=e.target;
    if(t.id.startsWith("dr_")){const f=t.id.slice(3); S.dense[f]=+t.value; S.denseOff[f]=+t.value; setFill(t); document.getElementById("dv_"+f).textContent=t.value+"개 이상"; schedule();}});
  pn.addEventListener("change",e=>{const t=e.target; if(t.type!=="checkbox") return;
    if(t.id.startsWith("fc_")){const f=t.id.slice(3), v=S.facOff[f]||10; S.fac[f]=t.checked?v:null; S.facOff[f]=v;
      document.getElementById("fx_"+f).classList.toggle("off",!t.checked); document.getElementById("fv_"+f).textContent=t.checked?v+"분 이내":"";}
    else if(t.id.startsWith("dc_")){const f=t.id.slice(3), v=S.denseOff[f]||10; S.dense[f]=t.checked?v:null;
      document.getElementById("dx_"+f).classList.toggle("off",!t.checked); document.getElementById("dv_"+f).textContent=t.checked?v+"개 이상":"";}
    else if(t.id==="nc"){S.nuis=t.checked?S.nuisOff:null; document.getElementById("nx").classList.toggle("off",!t.checked); document.getElementById("nv").textContent=t.checked?S.nuisOff+"개 이하":"";}
    else if(t.id==="sc"){S.sewer=t.checked?S.sewerOff:null; document.getElementById("sx").classList.toggle("off",!t.checked); document.getElementById("sv").textContent=t.checked?S.sewerOff+"km 이상":"";}
    else if(t.id==="nearOn"){S.near=t.checked; document.getElementById("allow2").disabled=!t.checked; document.getElementById("allow2Row").style.opacity=t.checked?1:.4;}
    else if(t.id==="allow2") S.allow2=t.checked;
    schedule();});
  pn.addEventListener("click",e=>{const b=e.target.closest("button"); if(!b) return;
    if(b.dataset.f){const f=b.dataset.f, m=+b.dataset.m; S.fac[f]=m; S.facOff[f]=m; b.parentNode.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b)); document.getElementById("fv_"+f).textContent=m+"분 이내"; schedule();}
    else if(b.dataset.sw){const k=+b.dataset.sw; S.sewer=k; S.sewerOff=k; b.parentNode.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b)); document.getElementById("sv").textContent=k+"km 이상"; schedule();}
    else if(b.id==="nMinus"||b.id==="nPlus"){S.nuisOff=Math.max(0,Math.min(20,S.nuisOff+(b.id==="nPlus"?1:-1))); S.nuis=S.nuisOff; document.getElementById("nv").textContent=S.nuis+"개 이하"; schedule();}
    else if(b.id==="bandRow"){const l=document.getElementById("bandList"), open=l.hidden; l.hidden=!open; b.setAttribute("aria-expanded",open); document.getElementById("bandChev").style.transform=open?"rotate(90deg)":"";}
    else if(b.dataset.band){S.band=+b.dataset.band; buildBand(); document.getElementById("bandList").hidden=true; document.getElementById("bandRow").setAttribute("aria-expanded",false); document.getElementById("bandChev").style.transform=""; schedule();}
  });
}

/* ───────── 계산 예약 ───────── */
let timer=null;
function schedule(){document.getElementById("main").classList.add("busy"); clearTimeout(timer);
  timer=setTimeout(()=>{compute(); SEL=null; PANE="list"; autoSelect(); render(); fitTo(R.cand.length?R.cand:R.near.map(n=>n.c),.08); document.getElementById("main").classList.remove("busy");},220);}

/* ───────── 선택 ───────── */
let SEL=null, SORT="price", SHOW_ALL=false, VIEW="cand", PANE="list";
function autoSelect(){
  if(!R.cand.length){SEL=R.near.length&&S.near?{kind:"miss",id:R.near[0].c}:null; return;}
  if(R.premium){const g=[...R.groups].filter(g=>!g.ref&&g.id!==R.base).sort((a,b)=>b.pct-a.pct)[0]||R.groups[R.base];
    SEL={kind:"apt",id:[...g.members].sort((a,b)=>R.P[b].n-R.P[a].n)[0]};} else SEL={kind:"apt",id:R.cand[0]};
}
function select(kind,id,fit){SEL={kind,id}; VIEW=kind==="miss"?"miss":"cand"; PANE="detail";
  renderTabs(); renderList(); renderMisses(); renderMap(); renderDetail(); renderGroups(); showPane();
  const ds=document.querySelector("#detailView .detailscroll"); if(ds) ds.scrollTop=0;
  if(fit){const g=kind==="apt"?R.groups[R.gOf.get(id)].members:[id]; fitTo(g);}}
const premOf=c=>{if(!R.premium) return null; const g=R.groups[R.gOf.get(c)]; return g.id===R.base?0:g.pct;};
const badge=(p,ref)=>{if(p==null) return ""; const t=p===0?TIERS[0]:tierOf(p); return `<span class="badge b${t.k}">${p===0?"기준 0%":"+"+r5(p)+"%"}${ref?" · 참고":""}</span>`;};
const valueText=v=>Math.abs(v)<5?"예상가와 비슷":v<0?`예상가보다 ${Math.round(-v/5)*5}% 쌈`:`예상가보다 ${Math.round(v/5)*5}% 비쌈`;

/* ───────── 화면 그리기 ───────── */
function render(){renderCta(); renderStats(); renderTabs(); renderList(); renderMisses(); renderMap(); renderDetail(); renderGroups(); showPane();}
function renderTabs(){
  if(!S.near&&VIEW==="miss") VIEW="cand";
  const tabs=[["cand",`조건 충족 ${R.cand.length}`]].concat(S.near?[["miss",`아깝게 놓친 ${R.near.length}`]]:[]);
  document.getElementById("viewSeg").innerHTML=tabs.map(([k,t])=>`<button type="button" role="tab" data-view="${k}" aria-pressed="${VIEW===k}" aria-selected="${VIEW===k}">${t}</button>`).join("");
}
function showPane(){
  document.getElementById("listView").hidden=PANE!=="list"; document.getElementById("detailView").hidden=PANE!=="detail";
  const cand=VIEW==="cand";
  document.getElementById("aptList").hidden=!cand; document.getElementById("missList").hidden=cand; document.getElementById("sortWrap").hidden=!cand;
  document.getElementById("listTitle").textContent=cand?`조건 충족 매물 ${R.cand.length}곳`:`아깝게 놓친 매물 ${R.near.length}곳`;
  document.getElementById("listSub").textContent=cand?`${BANDS[S.band].t} · ${eok(S.lo)}~${eok(S.hi)}`:`조건 ${S.allow2?"두 개까지":"하나만"} 조금 못 미침 · 프리미엄 계산에서 빼요`;
  document.getElementById("backLbl").textContent=cand?"조건 충족 매물":"아깝게 놓친 매물";
  if(PANE==="detail") fitLines(document.getElementById("detail"));
}
function scrollToCurrent(){const row=document.querySelector(`#${VIEW==="cand"?"aptList":"missList"} [aria-current="true"]`); if(row){const l=row.closest(".list"); l.scrollTop=row.offsetTop-l.offsetTop-l.clientHeight/2+row.clientHeight/2;}}
function renderCta(){
  const n=R.cand.length, m=S.near?R.near.length:0, el=document.getElementById("cta");
  el.classList.toggle("off",!n);
  document.getElementById("ctaText").textContent=n?`조건에 맞는 아파트 ${n}곳`+(m?` · 놓친 매물 ${m}곳`:""):(m?`조건 충족 0곳 · 놓친 매물 ${m}곳`:"조건에 맞는 아파트가 없어요");
}
function renderStats(){
  const b=BANDS[S.band];
  document.getElementById("stats").innerHTML=
    `<div class="stat"><span>조건 충족</span><b>${R.cand.length}<span style="font-size:15px;color:var(--label)">곳</span></b></div>`+
    `<div class="stat"><span>이웃 묶음 (2km)</span><b>${R.groups.length}<span style="font-size:15px;color:var(--label)">개</span></b></div>`+
    `<div class="stat"><span>가장 싼 동네 · 0% 기준</span><b class="sm">${R.premium?esc(R.groups[R.base].name):"—"}</b></div>`+
    `<div class="stat"><span>아깝게 놓친 매물</span><b style="color:var(--blue)">${S.near?R.near.length:0}<span style="font-size:15px">곳</span></b></div>`;
  let n="";
  if(!R.cand.length) n=`${b.t} · ${eok(S.lo)}~${eok(S.hi)} 조건을 모두 만족하는 아파트가 없어요. 예산을 넓히거나 시설 조건을 한두 개 꺼 보세요.`;
  else if(!R.premium) n=`비교할 동네 묶음이 ${R.groups.length}개뿐이라 프리미엄은 계산하지 않았어요. 3개 이상 필요해요.`;
  const nt=document.getElementById("notice"); nt.innerHTML=n?`<div class="notice">${n}</div>`:""; nt.hidden=!n;
  document.getElementById("groupCard").hidden=!R.premium;
}
function renderList(){
  const P=R.P, opts=[["price","싼 순"],["prem","프리미엄"]].filter(o=>R.premium||o[0]!=="prem");
  if(!opts.find(o=>o[0]===SORT)) SORT="price";
  document.getElementById("sortSeg").innerHTML=opts.map(([k,t])=>`<button type="button" data-sort="${k}" aria-pressed="${SORT===k}">${t}</button>`).join("");
  const L=[...R.cand].sort((a,c)=>SORT==="price"?P[a].price-P[c].price:SORT==="prem"?(premOf(c)-premOf(a))||P[a].price-P[c].price:P[a].price-P[c].price);
  const shown=SHOW_ALL?L:L.slice(0,30);
  document.getElementById("aptList").innerHTML=shown.map(c=>{const p=P[c], g=R.groups[R.gOf.get(c)];
    const sub=`${esc(APTS.gu[c])} ${esc(dongOf(c))}`;
    return `<button class="row apt" type="button" data-apt="${c}" aria-current="${SEL&&SEL.kind==="apt"&&SEL.id===c}"><span class="t"><span class="name">${esc(APTS.name[c])}</span><span class="meta">${sub}${p.win!==12?" · 오래된 거래 기준":""}</span></span>
      <span class="price">${won(p.price)}<br>${badge(premOf(c),R.premium&&g.ref)}</span>${chev}</button>`;}).join("")
    +(L.length>30?`<button class="row more" type="button" id="showAll">${SHOW_ALL?"접기":`${L.length-30}곳 더 보기`}</button>`:"")
    ||`<div class="empty">조건에 맞는 아파트가 없어요.</div>`;
}
function renderMisses(){
  if(!S.near) return;
  document.getElementById("missList").innerHTML=R.near.slice(0,30).map(it=>{
    const save=R.cand.length&&it.diff>0?`<span class="save">조건 충족 매물 중앙값보다 ${won(it.diff)} 저렴</span>`:"";
    return `<button class="row" type="button" data-miss="${it.c}" aria-current="${SEL&&SEL.kind==="miss"&&SEL.id===it.c}"><span class="t"><span style="font-weight:600;display:block">${esc(APTS.name[it.c])}</span>
      <span class="lost">${it.miss.map(m=>missText(m.cd,m.v)).join(" · ")}</span>${save}</span><span style="font-weight:700;white-space:nowrap">${won(it.price)}</span>${chev}</button>`;}).join("")
    ||`<div class="empty">허용 범위 안에서 아깝게 빠진 매물이 없어요.</div>`;
}
document.getElementById("main").addEventListener("click",e=>{
  const v=e.target.closest("[data-view]"); if(v){VIEW=v.dataset.view; PANE="list"; renderTabs(); showPane(); scrollToCurrent(); return;}
  if(e.target.closest("#backBtn")){PANE="list"; showPane(); scrollToCurrent(); return;}
  const s=e.target.closest("[data-sort]"); if(s){SORT=s.dataset.sort; renderList(); return;}
  if(e.target.closest("#showAll")){SHOW_ALL=!SHOW_ALL; renderList(); return;}
  const a=e.target.closest("[data-apt]"); if(a){select("apt",+a.dataset.apt,true); return;}
  const m=e.target.closest("[data-miss]"); if(m){select("miss",+m.dataset.miss,true); return;}
  const g=e.target.closest("[data-group]"); if(g){const gr=R.groups[+g.dataset.group]; select("apt",[...gr.members].sort((a,b)=>R.P[b].n-R.P[a].n)[0],true); return;}
  if(e.target.closest("#fitG")){const c=SEL.id; fitTo(SEL.kind==="apt"?R.groups[R.gOf.get(c)].members:[c]);}
});

/* ───────── 지도 (Leaflet) ───────── */
let MAP=null, TILE=null, LAYER=null, LINES=null;
const isDark=()=>{const t=document.documentElement.getAttribute("data-theme"); return t?t==="dark":matchMedia("(prefers-color-scheme: dark)").matches;};
const LINE_COLOR={"1호선":"#E5332A","2호선":"#2E9E5B","3호선":"#D9A21E"};
function setupMap(){
  MAP=L.map("map",{preferCanvas:true,zoomSnap:.5}).setView([35.86,128.6],11);
  setTiles(); drawLines();
}
function setTiles(){
  if(TILE) MAP.removeLayer(TILE);
  // CARTO 배경 지도 (OpenStreetMap 기반, 키 필요 없음). OSM 공식 타일은 파일로 열면(Referer 없음) Access blocked가 떠서 바꿈. 컬러 그대로 두되 마커가 잘 보이게 채도만 조금 낮추고, 다크 모드는 색을 뒤집어 어둡게
  TILE=L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
    {maxZoom:19,subdomains:"abcd",attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',className:"base-tiles"}).addTo(MAP);
  document.getElementById("map").classList.toggle("dark-tiles",isDark());
}
function drawLines(){
  const ST=META.stations; if(!ST) return; if(LINES) LINES.remove(); LINES=L.layerGroup().addTo(MAP);
  const by={}; ST.name.forEach((n,i)=>(by[ST.line[i]]??=[]).push(i));
  for(const [ln,ids] of Object.entries(by)){
    const col=LINE_COLOR[ln]||"#888", pts=ids.map(i=>[ST.lat[i],ST.lon[i]]);
    // 역 순서 정보가 없어 가까운 역끼리 이어 노선 모양을 근사 (3호선은 북쪽 끝, 나머지는 서쪽 끝에서 시작)
    const start=pts.reduce((bi,p,i)=>(ln==="3호선"?p[0]>pts[bi][0]:p[1]<pts[bi][1])?i:bi,0), used=new Set([start]), order=[start];
    while(order.length<pts.length){const l=pts[order[order.length-1]]; let best=-1,bd=Infinity;
      pts.forEach((p,i)=>{if(used.has(i)) return; const d=(p[0]-l[0])**2+((p[1]-l[1])*.82)**2; if(d<bd){bd=d;best=i;}}); used.add(best); order.push(best);}
    L.polyline(order.map(i=>pts[i]),{color:col,weight:4,opacity:.55,interactive:false}).addTo(LINES);
    ids.forEach((i,k)=>L.circleMarker(pts[k],{radius:3,color:col,weight:1.5,fillColor:"#fff",fillOpacity:1,interactive:true})
      .bindTooltip(`${esc(ST.name[i])}역 · ${ln}`,{direction:"top",className:"apt-tip"}).addTo(LINES));
  }
}
function fitTo(ids,pad){
  if(!ids.length||!MAP) return;
  if(ids.length===1){MAP.setView([APTS.lat[ids[0]],APTS.lon[ids[0]]],15); return;}
  MAP.fitBounds(L.latLngBounds(ids.map(i=>[APTS.lat[i],APTS.lon[i]])).pad(pad??.35),{maxZoom:15});
}
function tipHtml(kind,c){const p=R.P[c];
  return `<b>${esc(APTS.name[c])}</b><br>${esc(APTS.gu[c])} ${esc(dongOf(c))} · ${won(p.price)}`+(kind==="m"?"<br>아깝게 놓친 매물":R.premium?`<br>${premOf(c)===0?"가장 싼 동네 (0% 기준)":"동네 프리미엄 +"+r5(premOf(c))+"%"}`:"");}
function renderMap(){
  if(!MAP) return;
  if(LAYER) LAYER.remove(); LAYER=L.layerGroup().addTo(MAP);
  const selG=SEL&&SEL.kind==="apt"&&R.gOf.has(SEL.id)?R.gOf.get(SEL.id):null, cell=cssv("--cell"), ink=cssv("--label"), blue=cssv("--blue");
  if(S.near) for(const it of R.near){const on=SEL&&SEL.kind==="miss"&&SEL.id===it.c;
    L.circleMarker([APTS.lat[it.c],APTS.lon[it.c]],{radius:on?8:4.5,color:blue,weight:on?2.5:1.6,dashArray:"3 2",fillColor:cell,fillOpacity:.75})
      .bindTooltip(tipHtml("m",it.c),{direction:"top",className:"apt-tip"}).on("click",()=>select("miss",it.c,true)).addTo(LAYER);}
  const order=[...R.cand].sort((a,b)=>(R.gOf.get(a)===selG)-(R.gOf.get(b)===selG));
  for(const c of order){const inSel=selG!=null&&R.gOf.get(c)===selG, on=SEL&&SEL.kind==="apt"&&SEL.id===c;
    const p=premOf(c), col=p==null?blue:cssv(`--p${(p===0?TIERS[0]:tierOf(p)).k}`);
    L.circleMarker([APTS.lat[c],APTS.lon[c]],{radius:on?8.5:inSel?6:4.5,stroke:on,color:ink,weight:2.5,fillColor:col,fillOpacity:.95})
      .bindTooltip(tipHtml("a",c),{direction:"top",className:"apt-tip"}).on("click",()=>select("apt",c,true)).addTo(LAYER);}
  document.getElementById("legend").innerHTML=(R.premium?TIERS.map(t=>`<span><i style="background:var(--p${t.k})"></i>${t.name}${t.k===0?" (5% 미만)":t.k===1?" 5~15%":t.k===2?" 15~30%":" 30%+"}</span>`).join(""):`<span><i style="background:var(--blue)"></i>조건 충족</span>`)
    +(S.near?`<span><i class="ring"></i>아깝게 놓친 매물</span>`:"")+`<span><i style="background:${LINE_COLOR["1호선"]};border-radius:2px;height:4px;width:16px;vertical-align:2px"></i>도시철도 1·2·3호선</span>`;
}
function onTheme(){if(!MAP||!R) return; setTiles(); renderMap();}

/* ───────── 상세 ───────── */
function wonRange(a,b){a=Math.round(a/100)*100; b=Math.round(b/100)*100; return Math.abs(b-a)<500?won((a+b)/2):`${won(a)} ~ ${won(b)}`;}
function pctRange(a,b){const f=v=>(v<0?"−":"+")+Math.abs(r5(v))+"%"; a=r5(a); b=r5(b); return a===b?f(a):`${f(a)} ~ ${f(b)}`;}
function facGrid(c){
  // 지금 켜 둔 조건(cond)과 나머지 시설을 나눠 보여 줌. 켠 조건은 충족 여부 표시
  const act={};
  for(const cd of conds()) if(cd.kind!=="budget") act[cd.kind==="sewer"?"하수처리장":cd.f]={cd,st:check(c,cd,R.P)[0]};
  const want=cd=>cd.kind==="fac"?`${cd.lim}분 이내`:cd.kind==="dense"?`${cd.lim}개 이상`:cd.kind==="nuis"?`${cd.lim}개 이하`:`${cd.lim}km 이상`;
  const STAT=[["ok","✓ 충족"],["near","△ 아깝게 놓침"],["no","✕ 미달"]];
  const cell=(f,k,v,nm)=>{const a=act[f], st=a?STAT[a.st]:null;
    return `<div class="fc ${a?"on":"off"}">${icon(f)}<span class="tx"><span class="k">${k}</span><b>${v}</b>${nm?`<span class="nm">${nm}</span>`:""}`+
      (a?`<span class="cond ${st[0]}">${st[1]} · 조건 ${want(a.cd)}</span>`:"")+`</span></div>`;};
  const cells=FAC_ORDER.map(f=>{const F=APTS.fac[f], none=F.b[c]===99, nm=META.names[f][F.n[c]];
    return [f,cell(f,`${LABEL[f]}까지 도보`,none?"20분+":F.t[c].toFixed(0)+"분",none?"걸어서 20분 안에 없음":esc(nm||""))];});
  [...DENSE,NUIS].forEach(f=>cells.push([f,cell(f,`10분 안 ${LABEL[f]}`,APTS.dense[f][c]+"개","")]));
  const s=APTS.sewer[c]; cells.push(["하수처리장",cell("하수처리장","하수처리장 (직선)",s==null?"3km+":(s/1000).toFixed(1)+"km",s==null?"3km 안에 없음":"")]);
  const on=cells.filter(x=>act[x[0]]).map(x=>x[1]), off=cells.filter(x=>!act[x[0]]).map(x=>x[1]);
  if(!on.length) return `<div class="ghead" style="margin-top:4px">주변 시설</div><div class="facgrid">${off.join("")}</div>`;
  return `<div class="ghead" style="margin-top:4px">고른 조건 <span style="font-weight:400">(${on.length}개)</span></div><div class="facgrid">${on.join("")}</div>`+
    (off.length?`<div class="ghead" style="margin-top:4px">그 밖의 주변 시설</div><div class="facgrid">${off.join("")}</div>`:"");
}
// 한 줄 글씨가 칸보다 길면 글자 크기를 조금씩 줄여 한 줄에 맞춤 (최소 11px)
function fitLines(root){for(const e of root.querySelectorAll(".hero .meta, .splitlbl b")){e.style.fontSize=""; let f=parseFloat(getComputedStyle(e).fontSize); while(e.scrollWidth>e.clientWidth+1&&f>11){f-=.5; e.style.fontSize=f+"px";}}}
addEventListener("resize",()=>{const d=document.getElementById("detail"); if(d&&!document.getElementById("detailView").hidden) fitLines(d);});
function priceNote(p){
  const per=p.win===12?"최근 1년":p.win===24?"최근 2년":"전체 기간";
  const pre=p.win===12?"":p.win===24?"1년 안에 거래가 없어 ":"2년 안에 거래가 없어 ";
  const one=p.nw<3?` (이 단지는 ${per} 거래가 ${p.nw}건이라 한 값)`:Math.abs(Math.round(p.hi/100)-Math.round(p.lo/100))*100<500?" (범위 폭이 500만 원보다 좁아 한 값)":"";
  return `시세 범위 = ${pre}${per} 같은 평형 거래 ${p.nw}건을 지금 시점으로 보정한 뒤 가운데 50%. <b>${per} 거래가 3건 미만이면 범위 대신 한 값</b>으로 보여 줘요${one}`;
}
function renderDetail(){
  const el=document.getElementById("detail");
  if(!SEL){el.innerHTML=`<div class="chead"><h2>자세히</h2></div><div class="empty">목록이나 지도에서 아파트를 골라 보세요.</div>`; return;}
  const c=SEL.id, p=R.P[c], isMiss=SEL.kind==="miss";
  let h=`<div class="chead"><h2>${isMiss?`<span style="color:var(--blue)">아깝게 놓친 매물</span>`:"자세히"}</h2><button class="row" id="fitG" type="button" style="width:auto;min-height:0;padding:0;color:var(--blue);font-size:14px">지도에서 보기</button></div>
    <div class="hero"><h3>${esc(APTS.name[c])}</h3><div class="meta">${esc(APTS.gu[c])} ${esc(dongOf(c))} · ${p.area.toFixed(1)}㎡ · 거래 ${p.n}건 · 마지막 거래 ${p.last}</div>`;
  h+=`<div class="kv"><div><div class="lbl">시세 범위</div><div class="big rng">${wonRange(p.lo,p.hi)}</div></div>`;
  if(isMiss){
    const it=R.near.find(x=>x.c===c);
    h+=`</div><div class="note" style="color:var(--blue);font-weight:600;font-size:14px">놓친 조건 · ${it.miss.map(m=>missText(m.cd,m.v)).join(" · ")}</div>`;
    if(R.cand.length) h+=`<div class="note" style="font-size:14px;color:var(--label2)">조건 충족 매물 중앙값(${won(R.candMed)})보다 <b style="color:var(--save)">${it.diff>0?won(it.diff)+" 저렴":won(-it.diff)+" 비쌈"}</b>`+
      (it.loss!=null?(it.lossPct<.01?`. 놓친 조건 탓은 거의 없어서, 싼 이유가 다른 데 있어요.`:`. 그중 놓친 조건 탓은 약 ${won(it.loss)}, 나머지는 다른 이유예요.`):"")+`</div>`;
    h+=`<p class="note ex">${priceNote(p)}<br>조건이 같지 않아서 동네 프리미엄 계산에는 넣지 않아요.</p></div>`;
  } else {
    const g=R.groups[R.gOf.get(c)];
    if(R.premium&&g.id!==R.base&&g.pct>=5){const t=tierOf(g.pct);
      const has=g.lo!=null&&g.n>1, pLo=has?Math.min(g.lo,g.pct):g.pct, pHi=has?Math.max(g.hi,g.pct):g.pct;
      h+=`<div><div class="lbl">동네 프리미엄</div><div class="prem rng">${pctRange(pLo,pHi)} <span class="badge b${t.k}" style="vertical-align:middle;font-size:13px">${t.name}</span></div></div></div>`;
      const base=p.price/(1+g.pct/100), bLo=p.price/(1+pHi/100), bHi=p.price/(1+Math.max(pLo,-99)/100), share=Math.max(30,Math.min(100,base/p.price*100));
      h+=`<div class="note ex">${priceNote(p)}<br>프리미엄 범위 = 단지를 바꿔 다시 계산했을 때 80%가 들어오는 범위${g.n===1?" (동네에 단지가 1곳뿐이라 한 값)":""}${g.ref?" · 거래가 적어 참고용":""}</div>`;
      h+=`<div class="split"><span class="pl">동네 프리미엄</span><div class="a" style="width:${share}%">기본가</div><div class="b" style="width:${100-share}%"><span class="pl">동네 프리미엄</span></div></div>
        <div class="splitlbl"><b>${wonRange(bLo,bHi)}</b><b class="pb">+${wonRange(Math.max(0,p.price-bHi),p.price-bLo)}</b></div>
        <div class="note ex">조건이 같은 아파트 중 가장 싼 동네(${esc(R.groups[R.base].name)})에 있었다면 약 ${wonRange(bLo,bHi)}이었을 집이에요.</div></div>`;
      const dv=drivers(g);
      if(dv.length) h+=`<div class="ghead" style="margin-top:4px">가장 싼 동네와 다른 점</div><div>`+dv.map(d=>`<div class="row"><span class="t">${featName(d.k)}</span><span class="v"><b style="color:var(--label)">${featText(d.k,d.ov)}</b> vs ${featText(d.k,d.bv)}</span></div>`).join("")+`</div><p class="sub">비슷한 시설 조건을 가진 대구 아파트들의 거래 경향이에요. 시설이 가격을 바꾼다는 뜻은 아니에요.</p>`;
    } else {
      h+=`</div><div class="note" style="font-size:14px">${!R.premium?"비교할 동네가 적어 프리미엄은 계산하지 않았어요.":g.id===R.base?"같은 조건에서 <b>가장 싼 동네</b>예요. 프리미엄 0% 기준이에요.":"같은 조건의 가장 싼 동네와 비슷한 가격이에요."}</div><div class="note ex">${priceNote(p)}</div></div>`;
    }
  }
  h+=`${facGrid(c)}<p class="sub" style="padding-top:8px">학교는 실제 배정이 아니라 걸어서 가장 가까운 학교예요. 실거래가 기준이라 호가와 다를 수 있어요.</p>`;
  el.innerHTML=h; fitLines(el);
}

/* ───────── 동네별 프리미엄 ───────── */
function renderGroups(){
  if(!R.premium) return;
  const gs=[...R.groups].sort((a,b)=>b.pct-a.pct), mx=Math.max(30,...gs.map(g=>g.hi??g.pct));
  const selG=SEL&&SEL.kind==="apt"&&R.gOf.has(SEL.id)?R.gOf.get(SEL.id):null;
  document.getElementById("groupBars").innerHTML=gs.map(g=>{const t=g.id===R.base?TIERS[0]:tierOf(g.pct);
    const ci=g.lo!=null&&g.n>1?`<u style="left:${g.lo/mx*100}%;width:${Math.max(0,(g.hi-g.lo)/mx*100)}%"></u>`:"";
    return `<button class="gbar row" type="button" data-group="${g.id}" aria-current="${selG===g.id}" style="padding:6px 8px;border-radius:8px;display:grid">
      <span style="min-width:0">${esc(g.name)}<span style="display:block;font-size:12px;color:var(--label3)">${g.n}개 단지 · 거래 ${g.trades}건</span></span>
      <span class="track"><i style="width:${Math.max(1,g.pct/mx*100)}%;background:var(--p${t.k})"></i>${ci}</span>
      <b>${g.id===R.base?"0% 기준":"+"+r5(g.pct)+"%"}${g.ref?`<span style="display:block;font-size:11px;color:var(--label3);font-weight:500">참고</span>`:""}</b></button>`;}).join("");
}

/* ───────── 계산 방법 표 ───────── */
function renderMethod(){
  const v=META.val;
  document.getElementById("eyebrow").textContent=`대구 아파트 ${N.toLocaleString()}개 단지 · 실거래 ${META.n_trades.toLocaleString()}건 (${META.months})`;
  document.getElementById("modelTbl").innerHTML=`<thead><tr><th>가격 모델</th><th>아는 정보</th><th class="r">설명력 R²</th><th class="r">평균 오차</th><th class="r">2026년 거래 R²</th></tr></thead><tbody>
    <tr><td><b>모델 A</b></td><td>전용면적, 층, 단지 최고층 대비 높이, 연식, 거래 시점</td><td class="r">${v.A.r2.toFixed(2)}</td><td class="r">${v.A.err.toFixed(0)}%</td><td class="r">${v.A.r2_time.toFixed(2)}</td></tr>
    <tr><td><b>모델 B</b></td><td>모델 A + 시설 7종 도보 시간, 10분 안 시설 수, 하수처리장 거리</td><td class="r">${v.B.r2.toFixed(2)}</td><td class="r">${v.B.err.toFixed(0)}%</td><td class="r">${v.B.r2_time.toFixed(2)}</td></tr></tbody>`;
  document.getElementById("foot").textContent="그래디언트 부스팅(LightGBM) · 처음 보는 단지 기준 5겹 교차검증 · 동네 이름과 좌표는 모델에 넣지 않았어요 · 프리미엄은 지금 고른 조건의 후보끼리 비교한 값이라 조건을 바꾸면 달라져요.";
}

/* ───────── 조건 창 열고 닫기 ───────── */
function sideSummary(){return `${BANDS[S.band].t} · ${eok(S.lo)}~${eok(S.hi)} · 조건 ${conds().length-1}개`;}
function setSide(open,save){
  const lay=document.querySelector(".layout"), b=document.getElementById("sideBtn");
  lay.classList.toggle("closed",!open); b.setAttribute("aria-expanded",open); b.title=open?"조건 창 닫기":"조건 창 열기";
  document.getElementById("sideLbl").innerHTML=open?"조건 닫기":`조건 열기 <span class="chips">· ${sideSummary()}</span>`;
  if(save){try{localStorage.setItem("dp-side",open?"1":"0");}catch(e){}}
  // 지도 크기가 바뀌므로 다시 맞춤
  requestAnimationFrame(()=>{if(MAP){MAP.invalidateSize(); setTimeout(()=>MAP.invalidateSize(),250);}});
}
document.getElementById("sideBtn").addEventListener("click",()=>setSide(document.querySelector(".layout").classList.contains("closed"),true));
document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="\\"){e.preventDefault(); document.getElementById("sideBtn").click();}});

/* ───────── 화면 모드 ───────── */
const START_THEME="/*__THEME__*/system";
function setTheme(t,save){
  if(t==="system") document.documentElement.removeAttribute("data-theme"); else document.documentElement.setAttribute("data-theme",t);
  document.querySelectorAll("[data-theme-set]").forEach(b=>b.setAttribute("aria-pressed",b.dataset.themeSet===t));
  if(save){try{localStorage.setItem("dp-theme",t);}catch(e){}}
}
document.getElementById("themeSeg").addEventListener("click",e=>{const b=e.target.closest("[data-theme-set]"); if(b) setTheme(b.dataset.themeSet,true);});
(()=>{let t=START_THEME.replace("/*__THEME__*/",""); try{t=localStorage.getItem("dp-theme")||t;}catch(e){} setTheme(t,false);})();

/* ───────── 설명 보기 ───────── */
function setExplain(on,save){document.body.classList.toggle("explain",on); document.getElementById("explainOn").checked=on; if(save){try{localStorage.setItem("dp-explain",on?"1":"0");}catch(e){}}}
document.getElementById("explainOn").addEventListener("change",e=>setExplain(e.target.checked,true));
(()=>{let o="0"; try{o=localStorage.getItem("dp-explain")||"0";}catch(e){} setExplain(o==="1",false);})();

/* ───────── 시작 ───────── */
buildCond(); wireCond(); updateBudget(); setupMap(); renderMethod();
compute(); autoSelect(); render(); fitTo(R.cand,.08);
(()=>{let o="1"; try{o=localStorage.getItem("dp-side")||"1";}catch(e){} if(o==="0") setSide(false,false);})();
try{matchMedia("(prefers-color-scheme: dark)").addEventListener("change",onTheme);}catch(e){}
new MutationObserver(onTheme).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
</script>
'''

with open(OUT, "w", encoding="utf-8") as f:
    f.write(build_html())
print(f"단지 {N:,}곳 / 거래 {len(tr):,}건 ({meta['months']}) → {OUT} ({os.path.getsize(OUT) / 1e6:.1f}MB)")


# ==================================================================
# localhost로 열기 — HTML은 위에서 저장하고, 결과/ 폴더를 로컬 서버로 띄워 브라우저에서 엶
#   파일을 더블클릭(file://)으로 열면 배경 지도 서버가 접근을 막을 수 있어서 localhost로 여는 것을 권장
#   끄기: python 이파일.py --no-serve   /  포트 바꾸기: --port 8600
# ==================================================================
def serve_html(path, port=8501, open_browser=True):
    import functools
    import http.server
    import threading
    import urllib.parse
    import webbrowser
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.dirname(path))
    for p in range(port, port + 20):                      # 포트가 사용 중이면 다음 번호로
        try:
            httpd = http.server.ThreadingHTTPServer(("127.0.0.1", p), handler)
            break
        except OSError:
            continue
    else:
        raise OSError(f"{port}~{port + 19}번 포트를 모두 쓸 수 없습니다")
    url = f"http://localhost:{p}/" + urllib.parse.quote(os.path.basename(path))
    print(f"\n열기: {url}\n끄려면 Ctrl+C")
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("종료")


if __name__ == "__main__":
    import sys
    if "--no-serve" not in sys.argv:
        port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else 8501
        serve_html(OUT, port, open_browser="--no-browser" not in sys.argv)
